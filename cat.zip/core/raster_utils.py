##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################



import os
import re
import tempfile
import uuid

import numpy as np
from osgeo import gdal, osr
from qgis.core import (
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer
)


def _safe_name(name):
    text = str(name).strip() if name else "raster"
    text = re.sub(r"[^\w\-]+", "_", text, flags=re.UNICODE)
    text = re.sub(r"_+", "_", text)
    return text.strip("_") or "raster"


def build_temp_raster_path(name):
    temp_dir = tempfile.gettempdir()
    safe_name = _safe_name(name)
    unique_id = uuid.uuid4().hex[:8]
    return os.path.join(temp_dir, f"{safe_name}_{unique_id}.tif")


def build_temp_vector_path(name):
    temp_dir = tempfile.gettempdir()
    safe_name = _safe_name(name)
    unique_id = uuid.uuid4().hex[:8]
    return os.path.join(temp_dir, f"{safe_name}_{unique_id}.gpkg")


def create_temp_raster_from_array(
    array,
    extent,
    crs,
    pixel_size_x,
    pixel_size_y,
    name,
    gdal_type=gdal.GDT_Float32,
    nodata_value=-9999.0
):
    if array is None:
        return None, None

    write_array = np.asarray(array)
    if write_array.ndim != 2 or write_array.size == 0:
        return None, None

    rows, cols = write_array.shape
    if rows <= 0 or cols <= 0:
        return None, None

    file_path = build_temp_raster_path(name)
    write_array = np.array(write_array, copy=True)

    if np.issubdtype(write_array.dtype, np.floating):
        write_array = np.where(np.isnan(write_array), nodata_value, write_array)

    driver = gdal.GetDriverByName("GTiff")
    if driver is None:
        return None, None

    dataset = driver.Create(file_path, cols, rows, 1, gdal_type)
    if dataset is None:
        return None, None

    geotransform = (
        extent.xMinimum(),
        pixel_size_x,
        0.0,
        extent.yMaximum(),
        0.0,
        -pixel_size_y
    )
    dataset.SetGeoTransform(geotransform)

    srs = osr.SpatialReference()
    srs.ImportFromWkt(crs.toWkt())
    dataset.SetProjection(srs.ExportToWkt())

    band = dataset.GetRasterBand(1)
    if band is None:
        dataset = None
        return file_path, None

    band.WriteArray(write_array)
    band.SetNoDataValue(nodata_value)
    band.FlushCache()

    dataset.FlushCache()
    dataset = None

    raster_layer = QgsRasterLayer(file_path, name)
    if not raster_layer.isValid():
        return file_path, None

    return file_path, raster_layer


def add_raster_to_project(raster_layer, group_name=None):
    if raster_layer is not None and raster_layer.isValid():
        project = QgsProject.instance()
        if group_name:
            root = project.layerTreeRoot()
            group = root.findGroup(group_name)
            if not group:
                group = root.addGroup(group_name)
            project.addMapLayer(raster_layer, False)
            group.addLayer(raster_layer)
        else:
            project.addMapLayer(raster_layer)
        return True
    return False


def add_vector_to_project(vector_layer, group_name=None):
    if vector_layer is not None and vector_layer.isValid():
        project = QgsProject.instance()
        if group_name:
            root = project.layerTreeRoot()
            group = root.findGroup(group_name)
            if not group:
                group = root.addGroup(group_name)
            project.addMapLayer(vector_layer, False)
            group.addLayer(vector_layer)
        else:
            project.addMapLayer(vector_layer)
        return True
    return False


def normalize_array(array, nodata_value=-9999.0, constant_value=0.0):
    arr = np.asarray(array, dtype=float)

    valid_mask = np.isfinite(arr) & (arr != nodata_value)
    
    if not np.any(valid_mask):
        return np.full_like(arr, nodata_value, dtype=float)

    min_val = np.min(arr[valid_mask])
    max_val = np.max(arr[valid_mask])

    result = np.full_like(arr, nodata_value, dtype=float)

    if max_val == min_val:
        result[valid_mask] = float(constant_value)
        return result

    result[valid_mask] = (arr[valid_mask] - min_val) / (max_val - min_val)
    return result


def reclassify_normalized_array_to_five_classes(array, nodata_value=-9999.0):
    arr = np.asarray(array, dtype=float)
    result = np.full(arr.shape, 0, dtype=np.int16)

    valid_mask = np.isfinite(arr) & (arr != nodata_value)
    vals = arr[valid_mask]

    result[valid_mask] = np.select(
        [
            vals <= 0.2,
            (vals > 0.2) & (vals <= 0.4),
            (vals > 0.4) & (vals <= 0.6),
            (vals > 0.6) & (vals <= 0.8),
            vals > 0.8
        ],
        [1, 2, 3, 4, 5],
        default=0
    )

    return result


def polygonize_raster(raster_path, output_name, field_name="class_val", remove_zero_class=True):
    if not raster_path or not os.path.exists(raster_path):
        return None

    src_ds = gdal.Open(raster_path)
    if src_ds is None:
        return None

    src_band = src_ds.GetRasterBand(1)
    if src_band is None:
        src_ds = None
        return None

    vector_path = build_temp_vector_path(output_name)
    drv = gdal.GetDriverByName("GPKG")
    if drv is None:
        src_ds = None
        return None

    if os.path.exists(vector_path):
        drv.Delete(vector_path)

    dst_ds = drv.Create(vector_path, 0, 0, 0, gdal.GDT_Unknown)
    if dst_ds is None:
        src_ds = None
        return None

    srs = osr.SpatialReference()
    wkt = src_ds.GetProjection()
    if wkt:
        srs.ImportFromWkt(wkt)

    layer_name = _safe_name(output_name)
    dst_layer = dst_ds.CreateLayer(layer_name, srs=srs)

    from osgeo import ogr
    field_defn = ogr.FieldDefn(field_name, ogr.OFTInteger)
    dst_layer.CreateField(field_defn)

    mask_band = src_band if remove_zero_class else None
    
    gdal.Polygonize(src_band, mask_band, dst_layer, 0, [], callback=None)

    dst_ds.FlushCache()
    dst_ds = None
    src_ds = None

    vector_layer = QgsVectorLayer(f"{vector_path}|layername={layer_name}", output_name, "ogr")
    if not vector_layer.isValid():
        return None

    return vector_layer