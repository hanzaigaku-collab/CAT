##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes
from qgis.PyQt.QtCore import QVariant


def get_point_layers():
    return [
        layer for layer in QgsProject.instance().mapLayers().values()
        if layer.type() == QgsMapLayer.VectorLayer and layer.geometryType() == QgsWkbTypes.PointGeometry
    ]


def get_polygon_layers():
    return [
        layer for layer in QgsProject.instance().mapLayers().values()
        if layer.type() == QgsMapLayer.VectorLayer and layer.geometryType() == QgsWkbTypes.PolygonGeometry
    ]


def get_features(layer, selected_only=False):
    if layer is None:
        return []

    if selected_only:
        return layer.selectedFeatures()

    return list(layer.getFeatures())


def get_numeric_fields(layer):
    if layer is None:
        return []

    numeric_types = (
        QVariant.Int, 
        QVariant.UInt, 
        QVariant.LongLong, 
        QVariant.ULongLong, 
        QVariant.Double
    )
    
    return [field.name() for field in layer.fields() if field.type() in numeric_types]


def is_projected(layer):
    if not layer or not layer.crs().isValid():
        return False

    return not layer.crs().isGeographic()