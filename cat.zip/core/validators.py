##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


from qgis.core import QgsMapLayer, QgsWkbTypes, QgsFeatureRequest
from qgis.PyQt.QtCore import QVariant


def validate_layer_exists(layer):
    if layer is None:
        return False, "No hay una capa seleccionada."
    return True, ""


def validate_vector_point_layer(layer):
    if layer is None:
        return False, "No hay una capa seleccionada."

    if layer.type() != QgsMapLayer.VectorLayer:
        return False, "La capa seleccionada no es vectorial."

    if layer.geometryType() != QgsWkbTypes.PointGeometry:
        return False, "La capa seleccionada no es de tipo punto."

    return True, ""


def validate_vector_polygon_layer(layer):
    if layer is None:
        return False, "No hay una capa seleccionada."

    if layer.type() != QgsMapLayer.VectorLayer:
        return False, "La capa seleccionada no es vectorial."

    if layer.geometryType() != QgsWkbTypes.PolygonGeometry:
        return False, "La capa seleccionada no es de tipo polígono."

    return True, ""


def validate_projected_crs(layer):
    if layer is None:
        return False, "No hay una capa seleccionada."

    crs = layer.crs()
    if not crs.isValid():
        return False, "La capa no tiene un CRS válido."

    if crs.isGeographic():
        return False, (
            "La capa está en un sistema de coordenadas geográficas. "
            "Usa una proyección en metros antes de ejecutar el análisis."
        )

    return True, ""


def validate_min_features(layer, min_count=2, selected_only=False):
    if layer is None:
        return False, "No hay una capa seleccionada."

    count = layer.selectedFeatureCount() if selected_only else layer.featureCount()

    if count < min_count:
        return False, (
            f"La capa debe tener al menos {min_count} entidades "
            f"({'seleccionadas' if selected_only else 'válidas'}) para ejecutar el análisis."
        )

    return True, ""


def validate_group_field(layer, field_name):
    if not field_name:
        return True, ""

    if layer is None:
        return False, "No hay una capa seleccionada."

    field_names = [field.name() for field in layer.fields()]
    if field_name not in field_names:
        return False, f"El campo de agrupación '{field_name}' no existe en la capa."

    return True, ""


def validate_numeric_field(layer, field_name):
    if layer is None:
        return False, "No hay una capa seleccionada."

    if not field_name:
        return False, "Debes seleccionar un campo numérico."

    idx = layer.fields().indexFromName(field_name)
    
    if idx == -1:
        return False, f"El campo '{field_name}' no existe en la capa."

    field = layer.fields().at(idx)

    valid_types = {
        QVariant.Int,
        QVariant.UInt,
        QVariant.LongLong,
        QVariant.ULongLong,
        QVariant.Double
    }

    if field.type() not in valid_types:
        return False, (
            f"El campo '{field_name}' no es numérico. "
            "Selecciona un atributo cuantitativo como conteo, tasa o índice."
        )

    return True, ""


def detect_suspicious_projected_coordinates(layer, selected_only=False):
    if layer is None:
        return False, ""

    try:
        if selected_only:
            features = layer.selectedFeatures()[:200]
        else:
            request = QgsFeatureRequest().setLimit(200)
            features = list(layer.getFeatures(request))

        if not features:
            return False, ""

        xs = []
        ys = []

        for feat in features:
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue

            if layer.geometryType() == QgsWkbTypes.PointGeometry:
                if geom.isMultipart():
                    pt = geom.centroid().asPoint()
                else:
                    pt = geom.asPoint()
                xs.append(pt.x())
                ys.append(pt.y())
            else:
                bbox = geom.boundingBox()
                xs.extend([bbox.xMinimum(), bbox.xMaximum()])
                ys.extend([bbox.yMinimum(), bbox.yMaximum()])

        if not xs or not ys:
            return False, ""

        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        width = abs(xmax - xmin)
        height = abs(ymax - ymin)

        looks_like_degrees = (
            -180.0 <= xmin <= 180.0 and
            -180.0 <= xmax <= 180.0 and
            -90.0 <= ymin <= 90.0 and
            -90.0 <= ymax <= 90.0
        )

        very_small_extent = width < 1.0 and height < 1.0

        if looks_like_degrees:
            return True, (
                "Las coordenadas parecen estar en grados aunque la capa no es geográfica. "
                "Revisa si el CRS está mal asignado o si la capa no fue realmente reproyectada."
            )

        if very_small_extent:
            return True, (
                "La capa tiene una extensión muy pequeña para un análisis métrico. "
                "Revisa si las coordenadas, el CRS o la escala de los datos son correctos."
            )

        return False, ""

    except Exception:
        return False, ""