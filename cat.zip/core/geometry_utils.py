##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


import math
from statistics import median

from qgis.core import QgsGeometry, QgsPointXY, QgsRectangle


def calculate_mean_center(features):
    points = []

    for feat in features:
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue

        if geom.isMultipart():
            pt = geom.centroid().asPoint()
        else:
            pt = geom.asPoint()
            
        points.append(pt)

    if not points:
        return None

    mean_x = sum(pt.x() for pt in points) / len(points)
    mean_y = sum(pt.y() for pt in points) / len(points)

    return QgsPointXY(mean_x, mean_y)


def calculate_distances_from_center(center_point, features):
    distances = []

    if center_point is None:
        return distances

    cx = center_point.x()
    cy = center_point.y()

    for feat in features:
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue

        if geom.isMultipart():
            pt = geom.centroid().asPoint()
        else:
            pt = geom.asPoint()

        d = math.hypot(pt.x() - cx, pt.y() - cy)
        distances.append(d)

    return distances


def suggest_canter_radius(distances, method="max"):
    if not distances:
        return 0.0

    method = (method or "max").lower()

    if method == "mean":
        return sum(distances) / len(distances)

    if method == "median":
        return median(distances)

    if method == "p90":
        sorted_dist = sorted(distances)
        idx = int(len(sorted_dist) * 0.90) # Índice del 90%
        # Evita desbordamiento si la lista es pequeña
        idx = min(idx, len(sorted_dist) - 1) 
        return sorted_dist[idx]

    return max(distances)


def create_buffer_from_point(point, radius, segments=48):
    if point is None:
        return None

    return QgsGeometry.fromPointXY(point).buffer(radius, segments)


def create_square_from_center(center_point, half_size):
    if center_point is None:
        return None

    x = center_point.x()
    y = center_point.y()

    ring = [
        QgsPointXY(x - half_size, y - half_size),
        QgsPointXY(x + half_size, y - half_size),
        QgsPointXY(x + half_size, y + half_size),
        QgsPointXY(x - half_size, y + half_size),
        QgsPointXY(x - half_size, y - half_size), # Cerrar el anillo
    ]

    return QgsGeometry.fromPolygonXY([ring])


def calculate_extent_from_features(features):
    rect = None

    for feat in features:
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue

        bbox = geom.boundingBox()
        if rect is None:
            rect = QgsRectangle(bbox)
        else:
            rect.combineExtentWith(bbox)

    return rect


def expand_extent(rect, margin):
    if rect is None:
        return None

    return QgsRectangle(
        rect.xMinimum() - margin,
        rect.yMinimum() - margin,
        rect.xMaximum() + margin,
        rect.yMaximum() + margin
    )


def euclidean_distance_xy(x1, y1, x2, y2):
    return math.hypot(x2 - x1, y2 - y1)


def grid_dimensions(extent, cell_size):
    width = extent.width()
    height = extent.height()
    cols = max(1, int(math.ceil(width / cell_size)))
    rows = max(1, int(math.ceil(height / cell_size)))
    return rows, cols


def cell_center(extent, row, col, cell_size):
    x = extent.xMinimum() + (col + 0.5) * cell_size
    y = extent.yMaximum() - (row + 0.5) * cell_size
    return x, y