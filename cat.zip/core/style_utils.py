##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsFillSymbol,
    QgsMarkerSymbol,
    QgsSingleSymbolRenderer,
    QgsLineSymbol,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer,
    QgsRendererCategory,
    QgsCategorizedSymbolRenderer
)


def style_canter_layer(layer):
    if layer is None:
        return

    symbol = QgsFillSymbol.createSimple({
        "color": "255,0,0,40",
        "outline_color": "200,0,0,255",
        "outline_width": "0.8"
    })
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    layer.triggerRepaint()


def style_gottlieb_layer(layer):
    if layer is None:
        return

    symbol = QgsFillSymbol.createSimple({
        "color": "0,0,255,30",
        "outline_color": "0,0,180,255",
        "outline_width": "0.8"
    })
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    layer.triggerRepaint()


def style_center_layer(layer):
    if layer is None:
        return

    symbol = QgsMarkerSymbol.createSimple({
        "name": "circle",
        "color": "255,165,0,255",
        "outline_color": "80,80,80,255",
        "outline_width": "0.4",
        "size": "2.5"
    })
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    layer.triggerRepaint()


def style_jtc_line_layer(layer):
    if layer is None:
        return

    symbol = QgsLineSymbol.createSimple({
        "line_color": "128,0,128,220",
        "line_width": "0.6"
    })
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    layer.triggerRepaint()


def style_anchor_layer(layer):
    if layer is None:
        return

    symbol = QgsMarkerSymbol.createSimple({
        "name": "star",
        "color": "255,0,255,255",
        "outline_color": "60,60,60,255",
        "outline_width": "0.5",
        "size": "4.0"
    })
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    layer.triggerRepaint()


def style_near_repeat_line_layer(layer):
    if layer is None:
        return

    symbol = QgsLineSymbol.createSimple({
        "line_color": "255,140,0,220",
        "line_width": "0.7"
    })
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    layer.triggerRepaint()


def style_rossmo_raster(raster_layer):
    if raster_layer is None or not raster_layer.isValid():
        return

    provider = raster_layer.dataProvider()

    shader = QgsRasterShader()
    color_ramp = QgsColorRampShader()
    color_ramp.setColorRampType(QgsColorRampShader.Interpolated)

    items = [
        QgsColorRampShader.ColorRampItem(0.0, QColor("#ffffcc"), "Bajo"),
        QgsColorRampShader.ColorRampItem(0.25, QColor("#a1dab4"), "Medio-bajo"),
        QgsColorRampShader.ColorRampItem(0.5, QColor("#41b6c4"), "Medio"),
        QgsColorRampShader.ColorRampItem(0.75, QColor("#2c7fb8"), "Medio-alto"),
        QgsColorRampShader.ColorRampItem(1.0, QColor("#253494"), "Alto"),
    ]

    color_ramp.setColorRampItemList(items)
    shader.setRasterShaderFunction(color_ramp)

    renderer = QgsSingleBandPseudoColorRenderer(provider, 1, shader)
    raster_layer.setRenderer(renderer)
    raster_layer.triggerRepaint()

def style_rossmo_vector_layer(layer):
    if layer is None:
        return

    categories = []

    class_defs = {
        1: ("Muy bajo", "#ffffcc"),
        2: ("Bajo", "#a1dab4"),
        3: ("Medio", "#41b6c4"),
        4: ("Alto", "#2c7fb8"),
        5: ("Muy alto", "#253494"),
    }

    for value, (label, color) in class_defs.items():
        symbol = QgsFillSymbol.createSimple({
            "color": color,
            "outline_color": "120,120,120,120",
            "outline_width": "0.2"
        })
        categories.append(QgsRendererCategory(value, symbol, label))

    renderer = QgsCategorizedSymbolRenderer("class_val", categories)
    layer.setRenderer(renderer)
    layer.triggerRepaint()


def style_getis_ord_layer(layer):
    if layer is None:
        return

    categories = []

    defs = [
        ("Coldspot 99%", "#2166ac"),
        ("Coldspot 95%", "#67a9cf"),
        ("Coldspot 90%", "#d1e5f0"),
        ("No significativo", "#f7f7f7"),
        ("Hotspot 90%", "#fddbc7"),
        ("Hotspot 95%", "#ef8a62"),
        ("Hotspot 99%", "#b2182b"),
    ]

    for label, color in defs:
        symbol = QgsFillSymbol.createSimple({
            "color": color,
            "outline_color": "150,150,150,120",
            "outline_width": "0.2"
        })
        categories.append(QgsRendererCategory(label, symbol, label))

    renderer = QgsCategorizedSymbolRenderer("gi_class", categories)
    layer.setRenderer(renderer)
    layer.triggerRepaint()