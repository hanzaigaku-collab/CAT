##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsGeometry
)

def create_memory_layer(geometry_type, crs, name, fields):
    uri = f"{geometry_type}?crs={crs.authid()}"
    layer = QgsVectorLayer(uri, name, "memory")
    provider = layer.dataProvider()

    qgs_fields = [QgsField(name, f_type) for name, f_type in fields]

    provider.addAttributes(qgs_fields)
    layer.updateFields()

    return layer

def add_feature(layer, geometry, attributes):
    if layer is None or not isinstance(geometry, QgsGeometry):
        return False

    feature = QgsFeature(layer.fields())
    feature.setGeometry(geometry)
    feature.setAttributes(attributes)

    provider = layer.dataProvider()
    ok = provider.addFeature(feature)
    layer.updateExtents()

    return ok

def add_features(layer, features_data):
    if layer is None or not features_data:
        return False

    features = []
    for geom, attrs in features_data:
        if isinstance(geom, QgsGeometry):
            feat = QgsFeature(layer.fields())
            feat.setGeometry(geom)
            feat.setAttributes(attrs)
            features.append(feat)

    provider = layer.dataProvider()
    ok = provider.addFeatures(features)
    layer.updateExtents()

    return ok

def add_layer_to_project(layer, group_name=None):
    if layer is not None:
        project = QgsProject.instance()
        
        if group_name:
            root = project.layerTreeRoot()
            group = root.findGroup(group_name)
            if not group:
                group = root.addGroup(group_name)
            
            project.addMapLayer(layer, False) 
            group.addLayer(layer)
        else:
            project.addMapLayer(layer)
            
        return True
    return False