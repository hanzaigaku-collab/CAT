##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


import math

from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsGeometry

from ..core.validators import (
    validate_vector_point_layer,
    validate_projected_crs,
    validate_min_features,
    validate_group_field
)
from ..core.layer_utils import get_features
from ..core.geometry_utils import (
    calculate_mean_center,
    calculate_distances_from_center,
    create_buffer_from_point
)
from ..core.output_utils import (
    create_memory_layer,
    add_features, # UPGRADE: Inserción masiva
    add_layer_to_project
)
from ..core.style_utils import (
    style_canter_layer,
    style_center_layer
)
from ..core.report_utils import build_result_message


class CanterAnalysis:
    VALID_RADIUS_METHODS = ("max", "mean", "median", "p90")

    def validate(self, layer, params):
        ok, msg = validate_vector_point_layer(layer)
        if not ok:
            return False, msg

        ok, msg = validate_projected_crs(layer)
        if not ok:
            return False, msg

        selected_only = params.get("selected_only", False)
        ok, msg = validate_min_features(layer, min_count=2, selected_only=selected_only)
        if not ok:
            return False, msg

        group_field = params.get("group_field")
        ok, msg = validate_group_field(layer, group_field)
        if not ok:
            return False, msg

        radius = params.get("radius", 0.0)
        if radius < 0:
            return False, "El radio no puede ser negativo."

        radius_method = params.get("radius_method", "max")
        if radius_method not in self.VALID_RADIUS_METHODS:
            return False, f"Método de radio inválido: {radius_method}"

        return True, ""

    def _percentile(self, values, p):
        if not values:
            return 0.0

        vals = sorted(float(v) for v in values)
        if len(vals) == 1:
            return vals[0]

        k = (len(vals) - 1) * (p / 100.0)
        f = math.floor(k)
        c = math.ceil(k)

        if f == c:
            return vals[int(k)]

        d0 = vals[f] * (c - k)
        d1 = vals[c] * (k - f)
        return d0 + d1

    def suggest_radius(self, distances, method="max"):
        if not distances:
            return 0.0

        vals = [float(d) for d in distances]

        if method == "max":
            return max(vals)

        if method == "mean":
            return sum(vals) / len(vals)

        if method == "median":
            vals_sorted = sorted(vals)
            n = len(vals_sorted)
            mid = n // 2
            if n % 2 == 0:
                return (vals_sorted[mid - 1] + vals_sorted[mid]) / 2.0
            return vals_sorted[mid]

        if method == "p90":
            return self._percentile(vals, 90)

        return max(vals)

    def run(self, layer, params):
        ok, msg = self.validate(layer, params)
        if not ok:
            return {"success": False, "message": msg}

        selected_only = params.get("selected_only", False)
        radius_param = params.get("radius", 0.0)
        radius_method = params.get("radius_method", "max")
        output_name = params.get("output_name", "canter_output")
        
        group_field = params.get("group_field")

        all_features = get_features(layer, selected_only=selected_only)
        if not all_features:
            return {"success": False, "message": "No hay entidades válidas para analizar."}

        groups = {}
        if group_field:
            for feat in all_features:
                val = feat[group_field]
                group_key = str(val) if val is not None else "Sin_Grupo"
                if group_key not in groups:
                    groups[group_key] = []
                groups[group_key].append(feat)
        else:
            groups["Todos"] = all_features

        polygon_layer = create_memory_layer(
            "Polygon",
            layer.crs(),
            output_name,
            [
                ("grupo", QVariant.String),
                ("radius_m", QVariant.Double),
                ("radius_met", QVariant.String),
                ("n_points", QVariant.Int)
            ]
        )

        center_layer = create_memory_layer(
            "Point",
            layer.crs(),
            f"{output_name}_center",
            [
                ("grupo", QVariant.String),
                ("x", QVariant.Double),
                ("y", QVariant.Double)
            ]
        )

        poly_features_data = []
        center_features_data = []
        
        failed_groups = []

        for group_name, features in groups.items():
            if len(features) < 2:
                failed_groups.append(group_name)
                continue

            center_point = calculate_mean_center(features)
            if center_point is None:
                failed_groups.append(group_name)
                continue

            distances = calculate_distances_from_center(center_point, features)
            if not distances:
                failed_groups.append(group_name)
                continue

            auto_radius = self.suggest_radius(distances, method=radius_method)
            final_radius = radius_param if radius_param > 0 else auto_radius

            if final_radius <= 0:
                failed_groups.append(group_name)
                continue

            polygon_geom = create_buffer_from_point(center_point, final_radius)
            center_geom = QgsGeometry.fromPointXY(center_point)

            poly_features_data.append((polygon_geom, [group_name, float(final_radius), str(radius_method), int(len(features))]))
            center_features_data.append((center_geom, [group_name, float(center_point.x()), float(center_point.y())]))

        if poly_features_data:
            add_features(polygon_layer, poly_features_data)
            add_features(center_layer, center_features_data)

            project_group_name = "Canter Results"
            add_layer_to_project(polygon_layer, group_name=project_group_name)
            add_layer_to_project(center_layer, group_name=project_group_name)

            style_canter_layer(polygon_layer)
            style_center_layer(center_layer)

        warnings = []
        if failed_groups:
            warnings.append(f"No se procesaron los grupos {failed_groups} (necesitan al menos 2 puntos válidos).")
            
        outputs = []
        if poly_features_data:
            outputs = [polygon_layer.name(), center_layer.name()]
        else:
            return {"success": False, "message": "Ningún grupo tenía suficientes puntos para analizar."}

        message = build_result_message(
            module_name="Círculos de Canter",
            layer_name=layer.name(),
            feature_count=len(all_features),
            parameters={
                "Campo de agrupación": group_field if group_field else "Ninguno",
                "Grupos analizados": len(poly_features_data),
                "Método de radio automático": radius_method,
                "Radio manual forzado": f"{radius_param} m" if radius_param > 0 else "No (Automático)",
                "Solo seleccionados": selected_only
            },
            outputs=outputs,
            warnings=warnings,
            extra_lines=[
                "Centro: media geométrica simple de los eventos del grupo.",
                "El radio automático depende del método seleccionado."
            ]
        )

        return {"success": True, "message": message}