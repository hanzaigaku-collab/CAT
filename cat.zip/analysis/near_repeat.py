##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


import math
from datetime import datetime

from qgis.PyQt.QtCore import QVariant, QDate, QDateTime
from qgis.core import QgsGeometry, QgsPointXY

from ..core.validators import (
    validate_vector_point_layer,
    validate_projected_crs,
    validate_min_features
)
from ..core.output_utils import (
    create_memory_layer,
    add_features, # UPGRADE: Cambiamos a la inserción masiva
    add_layer_to_project
)
from ..core.style_utils import style_near_repeat_line_layer
from ..core.report_utils import build_result_message


class NearRepeatAnalysis:
    def validate(self, layer, params):
        ok, msg = validate_vector_point_layer(layer)
        if not ok:
            return False, msg

        ok, msg = validate_projected_crs(layer)
        if not ok:
            return False, msg

        selected_only = params.get("selected_only", False)
        ok, msg = validate_min_features(layer, min_count=2, selected_only=selected_only)
        if not ok:
            return False, msg

        time_field = params.get("time_field")
        if not time_field:
            return False, "Debes seleccionar un campo temporal."

        field_names = [field.name() for field in layer.fields()]
        if time_field not in field_names:
            return False, f"El campo temporal '{time_field}' no existe en la capa."

        spatial_threshold = params.get("spatial_threshold", 200.0)
        temporal_threshold = params.get("temporal_threshold", 7.0)
        temporal_unit = params.get("temporal_unit", "Días")

        if spatial_threshold <= 0:
            return False, "El umbral espacial debe ser mayor que 0."

        if temporal_threshold <= 0:
            return False, "El umbral temporal debe ser mayor que 0."

        if temporal_unit not in ("Días", "Horas"):
            return False, "La unidad temporal debe ser 'Días' o 'Horas'."

        return True, ""

    def _parse_datetime(self, value):
        if value is None:
            return None

        if isinstance(value, QDateTime):
            return value.toPyDateTime()

        if isinstance(value, QDate):
            return datetime(value.year(), value.month(), value.day())

        if isinstance(value, datetime):
            return value

        text = str(value).strip()
        if not text:
            return None

        patterns = [
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d",
            "%d/%m/%Y %H:%M:%S",
            "%d/%m/%Y %H:%M",
            "%d/%m/%Y",
            "%d-%m-%Y %H:%M:%S",
            "%d-%m-%Y %H:%M",
            "%d-%m-%Y",
        ]

        for fmt in patterns:
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                continue

        return None

    def run(self, layer, params):
        ok, msg = self.validate(layer, params)
        if not ok:
            return {"success": False, "message": msg}

        selected_only = params.get("selected_only", False)
        time_field = params.get("time_field")
        spatial_threshold = params.get("spatial_threshold", 200.0)
        temporal_threshold = params.get("temporal_threshold", 7.0)
        temporal_unit = params.get("temporal_unit", "Días")
        output_name = params.get("output_name", "near_repeat_output")

        features = layer.selectedFeatures() if selected_only else list(layer.getFeatures())
        
        valid_events = []
        invalid_time_count = 0

        for feat in features:
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue

            dt = self._parse_datetime(feat[time_field])
            if dt is None:
                invalid_time_count += 1
                continue

            # UPGRADE: Protección contra geometrías MultiPoint
            if geom.isMultipart():
                pt = geom.centroid().asPoint()
            else:
                pt = geom.asPoint()

            valid_events.append({
                "id": int(feat.id()),
                "dt": dt,
                "xy": QgsPointXY(pt.x(), pt.y())
            })

        if len(valid_events) < 2:
            return {
                "success": False,
                "message": "No hay suficientes eventos con fecha/hora válida para ejecutar Near Repeat."
            }

        valid_events.sort(key=lambda e: e["dt"])

        line_layer = create_memory_layer(
            "LineString",
            layer.crs(),
            output_name,
            [
                ("event_i", QVariant.Int),
                ("event_j", QVariant.Int),
                ("dist_m", QVariant.Double),
                ("dt_diff", QVariant.Double),
                ("dt_unit", QVariant.String),
                ("dt_hours", QVariant.Double),
                ("dt_days", QVariant.Double)
            ]
        )

        total_pairs = 0
        near_pairs = 0
        distances = []
        time_diffs = []
        
        new_features_data = []

        for i in range(len(valid_events)):
            a = valid_events[i]

            for j in range(i + 1, len(valid_events)):
                b = valid_events[j]
                total_pairs += 1

                delta_seconds = (b["dt"] - a["dt"]).total_seconds()
                dt_hours = delta_seconds / 3600.0
                dt_days = delta_seconds / 86400.0

                delta_value = dt_hours if temporal_unit == "Horas" else dt_days

                if delta_value > temporal_threshold:
                    break

                dx = b["xy"].x() - a["xy"].x()
                dy = b["xy"].y() - a["xy"].y()
                dist_m = math.hypot(dx, dy)

                if dist_m <= spatial_threshold:
                    near_pairs += 1
                    distances.append(dist_m)
                    time_diffs.append(delta_value)

                    line_geom = QgsGeometry.fromPolylineXY([a["xy"], b["xy"]])
                    attrs = [
                        a["id"],
                        b["id"],
                        float(dist_m),
                        float(delta_value),
                        temporal_unit,
                        float(dt_hours),
                        float(dt_days)
                    ]
                    new_features_data.append((line_geom, attrs))

        warnings = []
        if invalid_time_count > 0:
            warnings.append(
                f"Se omitieron {invalid_time_count} eventos por no tener fecha/hora interpretable."
            )

        extra_lines = [
            f"Eventos válidos evaluados: {len(valid_events)}",
            f"Pares evaluados cronológicamente: {total_pairs}",
            f"Pares near repeat: {near_pairs}"
        ]

        outputs = []

        if near_pairs > 0:
            add_features(line_layer, new_features_data)
            
            add_layer_to_project(line_layer, group_name="Near Repeat Results")
            style_near_repeat_line_layer(line_layer)
            outputs.append(line_layer.name())

            extra_lines.extend([
                f"Distancia mínima: {round(min(distances), 3)} m",
                f"Distancia máxima: {round(max(distances), 3)} m",
                f"Distancia media: {round(sum(distances) / len(distances), 3)} m",
                f"Diferencia temporal mínima: {round(min(time_diffs), 3)} {temporal_unit.lower()}",
                f"Diferencia temporal máxima: {round(max(time_diffs), 3)} {temporal_unit.lower()}"
            ])
        else:
            warnings.append("No se encontraron pares que cumplan simultáneamente los umbrales espacial y temporal.")

        message = build_result_message(
            module_name="Near Repeat",
            layer_name=layer.name(),
            feature_count=len(valid_events),
            parameters={
                "Campo temporal": time_field,
                "Umbral espacial": f"{spatial_threshold} m",
                "Umbral temporal": f"{temporal_threshold} {temporal_unit.lower()}",
                "Solo seleccionados": selected_only
            },
            outputs=outputs,
            warnings=warnings,
            extra_lines=extra_lines
        )

        return {"success": True, "message": message}