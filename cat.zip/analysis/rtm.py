##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


import math
import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsGeometry,
    QgsPointXY,
    QgsRectangle,
    QgsMapLayer,
    QgsWkbTypes
)

from ..core.validators import validate_projected_crs
from ..core.raster_utils import (
    create_temp_raster_from_array,
    add_raster_to_project,
    add_vector_to_project,
    reclassify_normalized_array_to_five_classes,
    polygonize_raster,
    normalize_array
)
from ..core.style_utils import (
    style_rossmo_raster,
    style_rossmo_vector_layer
)
from ..core.report_utils import build_result_message


class RTMAnalysis:
    VALID_INFLUENCE_TYPES = ("buffer", "linear", "inverse", "exponential")

    def validate(self, factors, params):
        if not factors or len(factors) == 0:
            return False, "Debes agregar al menos un factor para ejecutar RTM."

        cell_size = params.get("cell_size", 100.0)
        margin = params.get("margin", 1000.0)

        if cell_size <= 0:
            return False, "El tamaño de celda debe ser mayor que 0."

        if margin < 0:
            return False, "El margen no puede ser negativo."

        base_crs_authid = None

        for i, factor in enumerate(factors, start=1):
            layer = factor.get("layer")
            factor_name = factor.get("factor_name", f"factor_{i}")
            influence_type = str(factor.get("influence_type", "")).strip().lower()
            distance = factor.get("distance", 0.0)
            weight = factor.get("weight", 1.0)

            if layer is None:
                return False, f"El factor {i} no tiene una capa válida."

            if layer.type() != QgsMapLayer.VectorLayer:
                return False, f"El factor '{factor_name}' no es una capa vectorial."

            ok, msg = validate_projected_crs(layer)
            if not ok:
                return False, f"Factor '{factor_name}': {msg}"

            crs_authid = layer.crs().authid()
            if base_crs_authid is None:
                base_crs_authid = crs_authid
            elif crs_authid != base_crs_authid:
                return False, "Todos los factores deben estar en el mismo CRS proyectado."

            if influence_type not in self.VALID_INFLUENCE_TYPES:
                return False, (
                    f"Factor '{factor_name}': el tipo de influencia debe ser uno de "
                    f"{', '.join(self.VALID_INFLUENCE_TYPES)}."
                )

            if distance <= 0:
                return False, f"Factor '{factor_name}': la distancia debe ser mayor que 0."

            if weight < 0:
                return False, f"Factor '{factor_name}': el peso no puede ser negativo."

        return True, ""

    def build_analysis_extent(self, factors, margin):
        xmin, ymin, xmax, ymax = None, None, None, None

        for factor in factors:
            ext = factor["layer"].extent()
            xmin = ext.xMinimum() if xmin is None else min(xmin, ext.xMinimum())
            ymin = ext.yMinimum() if ymin is None else min(ymin, ext.yMinimum())
            xmax = ext.xMaximum() if xmax is None else max(xmax, ext.xMaximum())
            ymax = ext.yMaximum() if ymax is None else max(ymax, ext.yMaximum())

        return QgsRectangle(
            xmin - margin,
            ymin - margin,
            xmax + margin,
            ymax + margin
        )

    def compute_grid_size(self, extent, cell_size):
        cols = max(1, int(math.ceil(extent.width() / cell_size)))
        rows = max(1, int(math.ceil(extent.height() / cell_size)))
        return rows, cols

    def build_factor_cache(self, factor):
        layer = factor["layer"]
        is_point = layer.geometryType() == QgsWkbTypes.PointGeometry
        geometries = []

        for feat in layer.getFeatures():
            geom = feat.geometry()
            if geom and not geom.isEmpty():
                geometries.append(geom)

        return {
            "layer": layer,
            "factor_name": factor["factor_name"],
            "influence_type": str(factor["influence_type"]).strip().lower(),
            "distance": float(factor["distance"]),
            "weight": float(factor["weight"]),
            "is_point": is_point,
            "geometries": geometries
        }

    def compute_factor_array(
        self,
        factor_cache,
        extent,
        rows,
        cols,
        cell_size,
        progress_callback=None,
        progress_range=None,
        is_cancelled_callback=None
    ):
        dist_matrix = np.full((rows, cols), np.inf, dtype=np.float32)
        
        max_dist = factor_cache["distance"]
        influence_type = factor_cache["influence_type"]
        is_point = factor_cache["is_point"]
        geometries = factor_cache["geometries"]

        total_feats = len(geometries)
        start_p, end_p = progress_range if progress_range else (0, 100)

        for i, geom in enumerate(geometries):
            if is_cancelled_callback and is_cancelled_callback():
                return None

            if is_point:
                if geom.isMultipart():
                    pt = geom.centroid().asPoint()
                else:
                    pt = geom.asPoint()
                px, py = pt.x(), pt.y()
                
                c_min = max(0, int((px - max_dist - extent.xMinimum()) / cell_size))
                c_max = min(cols - 1, int((px + max_dist - extent.xMinimum()) / cell_size))
                r_min = max(0, int((extent.yMaximum() - (py + max_dist)) / cell_size))
                r_max = min(rows - 1, int((extent.yMaximum() - (py - max_dist)) / cell_size))
            else:
                bbox = geom.boundingBox()
                c_min = max(0, int((bbox.xMinimum() - max_dist - extent.xMinimum()) / cell_size))
                c_max = min(cols - 1, int((bbox.xMaximum() + max_dist - extent.xMinimum()) / cell_size))
                r_min = max(0, int((extent.yMaximum() - (bbox.yMaximum() + max_dist)) / cell_size))
                r_max = min(rows - 1, int((extent.yMaximum() - (bbox.yMinimum() - max_dist)) / cell_size))

            if c_min > c_max or r_min > r_max:
                continue

            if is_point:
                # Para puntos, NumPy lo hace de golpe en C++
                x_c = extent.xMinimum() + (np.arange(c_min, c_max + 1) + 0.5) * cell_size
                y_c = extent.yMaximum() - (np.arange(r_min, r_max + 1) + 0.5) * cell_size
                X, Y = np.meshgrid(x_c, y_c)
                d_sub = np.hypot(X - px, Y - py)
                
                sub_view = dist_matrix[r_min:r_max+1, c_min:c_max+1]
                np.minimum(sub_view, d_sub, out=sub_view)
            else:
                for r in range(r_min, r_max + 1):
                    cy = extent.yMaximum() - (r + 0.5) * cell_size
                    for c in range(c_min, c_max + 1):
                        if dist_matrix[r, c] == 0: 
                            continue # Si ya está en distancia 0, no puede mejorar
                        
                        cx = extent.xMinimum() + (c + 0.5) * cell_size
                        pt_geom = QgsGeometry.fromPointXY(QgsPointXY(cx, cy))
                        d = geom.distance(pt_geom)
                        if d < dist_matrix[r, c]:
                            dist_matrix[r, c] = d

            if progress_callback and total_feats > 0 and i % max(1, total_feats // 20) == 0:
                local_pct = int((i / total_feats) * (end_p - start_p))
                progress_callback(start_p + local_pct)

        arr = np.zeros((rows, cols), dtype=np.float32)
        valid_mask = dist_matrix <= max_dist

        if influence_type == "buffer":
            arr[valid_mask] = 1.0
        elif influence_type == "linear":
            arr[valid_mask] = 1.0 - (dist_matrix[valid_mask] / max_dist)
        elif influence_type == "inverse":
            arr[valid_mask] = 1.0 / (1.0 + dist_matrix[valid_mask])
        elif influence_type == "exponential":
            arr[valid_mask] = np.exp(-dist_matrix[valid_mask] / max_dist)

        return arr

    def run(self, factors, params, progress_callback=None, is_cancelled_callback=None):
        ok, msg = self.validate(factors, params)
        if not ok:
            return {"success": False, "message": msg}

        cell_size = params.get("cell_size", 100.0)
        margin = params.get("margin", 1000.0)
        output_name = params.get("output_name", "rtm_output")

        extent = self.build_analysis_extent(factors, margin)
        rows, cols = self.compute_grid_size(extent, cell_size)
        total_cells = rows * cols

        if total_cells > 10000000:
            return {"success": False,
                "message": (
                    f"La grilla es demasiado grande ({total_cells} celdas). "
                    "Aumenta el tamaño de celda o reduce el margen."
                )
            }

        factor_caches = [self.build_factor_cache(factor) for factor in factors]
        factor_arrays = []
        n_factors = len(factor_caches)

        for idx, factor_cache in enumerate(factor_caches):
            if is_cancelled_callback and is_cancelled_callback():
                return {"success": False, "message": "La ejecución de RTM fue cancelada por el usuario."}

            start_p = int((idx / n_factors) * 100)
            end_p = int(((idx + 1) / n_factors) * 100)

            if progress_callback:
                progress_callback(start_p, f"Procesando factor: {factor_cache['factor_name']}...")

            arr = self.compute_factor_array(
                factor_cache, extent, rows, cols, cell_size,
                progress_callback, (start_p, end_p), is_cancelled_callback
            )

            if arr is None:
                return {"success": False, "message": "La ejecución de RTM fue cancelada por el usuario."}

            factor_arrays.append(arr * factor_cache["weight"])

        if not factor_arrays:
            return {"success": False, "message": "No fue posible calcular superficies de factores."}

        raw_scores = np.sum(factor_arrays, axis=0)
        
        normalized_scores = normalize_array(raw_scores, nodata_value=-9999.0, constant_value=0.0)
        classes = reclassify_normalized_array_to_five_classes(normalized_scores, nodata_value=-9999.0)

        group_name = "RTM Results"

        raw_path, raw_raster_layer = create_temp_raster_from_array(
            raw_scores, extent, factor_caches[0]["layer"].crs(),
            cell_size, cell_size, f"{output_name}_raw",
            gdal_type=gdal.GDT_Float32, nodata_value=-9999.0
        )

        if raw_raster_layer is None:
            return {"success": False, "message": "No fue posible crear el raster bruto RTM."}

        add_raster_to_project(raw_raster_layer, group_name=group_name)
        style_rossmo_raster(raw_raster_layer)

        norm_path, norm_raster_layer = create_temp_raster_from_array(
            normalized_scores, extent, factor_caches[0]["layer"].crs(),
            cell_size, cell_size, f"{output_name}_norm",
            gdal_type=gdal.GDT_Float32, nodata_value=-9999.0
        )

        if norm_raster_layer is None:
            return {"success": False, "message": "No fue posible crear el raster normalizado RTM."}

        add_raster_to_project(norm_raster_layer, group_name=group_name)
        style_rossmo_raster(norm_raster_layer)

        class_path, class_raster_layer = create_temp_raster_from_array(
            classes, extent, factor_caches[0]["layer"].crs(),
            cell_size, cell_size, f"{output_name}_class",
            gdal_type=gdal.GDT_Int16, nodata_value=0
        )

        vector_layer = None
        if class_raster_layer is not None and class_path:
            vector_layer = polygonize_raster(
                class_path, f"{output_name}_poly",
                field_name="class_val", remove_zero_class=True
            )
            if vector_layer is not None:
                provider = vector_layer.dataProvider()

                if provider.fieldNameIndex("class_name") == -1:
                    from qgis.PyQt.QtCore import QVariant
                    from qgis.core import QgsField
                    provider.addAttributes([QgsField("class_name", QVariant.String)])
                    vector_layer.updateFields()

                idx_val = vector_layer.fields().indexFromName("class_val")
                idx_name = vector_layer.fields().indexFromName("class_name")

                label_map = {1: "Muy bajo", 2: "Bajo", 3: "Medio", 4: "Alto", 5: "Muy alto"}

                updates = {}
                for feat in vector_layer.getFeatures():
                    class_val = feat[idx_val]
                    updates[feat.id()] = {idx_name: label_map.get(class_val, "Sin clase")}

                provider.changeAttributeValues(updates)
                add_vector_to_project(vector_layer, group_name=group_name)
                style_rossmo_vector_layer(vector_layer)

        raw_finite = raw_scores[(np.isfinite(raw_scores)) & (raw_scores != -9999.0)]
        norm_finite = normalized_scores[(np.isfinite(normalized_scores)) & (normalized_scores != -9999.0)]

        raw_min = float(np.min(raw_finite)) if raw_finite.size else 0.0
        raw_max = float(np.max(raw_finite)) if raw_finite.size else 0.0
        raw_mean = float(np.mean(raw_finite)) if raw_finite.size else 0.0

        norm_min = float(np.min(norm_finite)) if norm_finite.size else 0.0
        norm_max = float(np.max(norm_finite)) if norm_finite.size else 0.0

        outputs = [raw_raster_layer.name(), norm_raster_layer.name()]
        if vector_layer is not None:
            outputs.append(vector_layer.name())

        factor_lines = []
        for factor in factor_caches:
            factor_lines.append(
                f"  • {factor['factor_name']} | "
                f"Capa: <i>{factor['layer'].name()}</i> | "
                f"Influencia: <i>{factor['influence_type']}</i> | "
                f"Distancia: <i>{factor['distance']}</i> | "
                f"Peso: <i>{factor['weight']}</i>"
            )

        message = build_result_message(
            module_name="Risk Terrain Modeling (NumPy Engine)",
            layer_name="Múltiples factores",
            feature_count=len(factors),
            parameters={
                "Tamaño de celda": cell_size,
                "Margen": margin
            },
            outputs=outputs,
            extra_lines=[
                "<b>Implementación:</b> Aproximación exploratoria de superficie de riesgo mediante álgebra de mapas matricial.",
                "<b>Nota Metodológica:</b> Los pesos son heurísticos (definidos por el analista) y no calibrados por regresión de Poisson.",
                f"Dimensiones de Grilla: {rows}x{cols} ({total_cells:,} celdas)",
                f"Score bruto [Min: {round(raw_min, 6)} | Max: {round(raw_max, 6)} | Med: {round(raw_mean, 6)}]",
                f"Score normalizado [Min: {round(norm_min, 6)} | Max: {round(norm_max, 6)}]",
                "",
                "<b>Factores combinados:</b>"
            ] + factor_lines
        )

        return {"success": True, "message": message}