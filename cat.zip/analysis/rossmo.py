##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


import math
import numpy as np
from osgeo import gdal

from qgis.core import QgsRectangle

from ..core.validators import (
    validate_vector_point_layer,
    validate_projected_crs,
    validate_min_features
)
from ..core.raster_utils import (
    create_temp_raster_from_array,
    add_raster_to_project,
    add_vector_to_project,
    reclassify_normalized_array_to_five_classes,
    polygonize_raster,
    normalize_array
)
from ..core.style_utils import (
    style_rossmo_raster,
    style_rossmo_vector_layer
)
from ..core.report_utils import build_result_message


class RossmoAnalysis:
    EPSILON = 1e-6 
    MAX_GRID_CELLS = 10000000 # UPGRADE: Aumentamos el límite gracias a NumPy

    def validate(self, layer, params):
        ok, msg = validate_vector_point_layer(layer)
        if not ok:
            return False, msg

        ok, msg = validate_projected_crs(layer)
        if not ok:
            return False, msg

        selected_only = params.get("selected_only", False)
        ok, msg = validate_min_features(layer, min_count=2, selected_only=selected_only)
        if not ok:
            return False, msg

        cell_size = params.get("cell_size", 100.0)
        margin = params.get("margin", 1000.0)
        buffer_zone = params.get("buffer_zone", 500.0)
        f = params.get("f", 1.2)
        g = params.get("g", 1.2)
        k = params.get("k", 1.0)

        if cell_size <= 0:
            return False, "El tamaño de celda debe ser mayor que 0."

        if margin < 0:
            return False, "El margen no puede ser negativo."

        if buffer_zone <= 0:
            return False, "La buffer zone debe ser mayor que 0."

        if f <= 0 or g <= 0 or k <= 0:
            return False, "Los parámetros f, g y k deben ser mayores que 0."

        return True, ""

    def get_valid_features(self, layer, selected_only=False):
        features = list(layer.selectedFeatures()) if selected_only else list(layer.getFeatures())
        pts = []
        for ft in features:
            geom = ft.geometry()
            if geom and not geom.isEmpty():
                if geom.isMultipart():
                    pts.append(geom.centroid().asPoint())
                else:
                    pts.append(geom.asPoint())
        return pts

    def build_extent(self, points, margin):
        xmin = min(p.x() for p in points)
        xmax = max(p.x() for p in points)
        ymin = min(p.y() for p in points)
        ymax = max(p.y() for p in points)

        return QgsRectangle(
            xmin - margin,
            ymin - margin,
            xmax + margin,
            ymax + margin
        )

    def compute_grid_size(self, extent, cell_size):
        cols = max(1, int(math.ceil(extent.width() / cell_size)))
        rows = max(1, int(math.ceil(extent.height() / cell_size)))
        return rows, cols

    def compute_score_surface(
        self,
        points,
        extent,
        rows,
        cols,
        cell_size,
        buffer_zone,
        f,
        g,
        k,
        progress_callback=None,
        is_cancelled_callback=None
    ):
        if is_cancelled_callback and is_cancelled_callback():
            return None

        x_coords = extent.xMinimum() + (np.arange(cols) + 0.5) * cell_size
        y_coords = extent.yMaximum() - (np.arange(rows) + 0.5) * cell_size

        X, Y = np.meshgrid(x_coords, y_coords)
        
        total_score = np.zeros((rows, cols), dtype=np.float64)
        
        bg_f = float(buffer_zone ** (g - f))
        two_b = 2.0 * buffer_zone

        total_points = len(points)
        
        for idx, pt in enumerate(points):
            if is_cancelled_callback and is_cancelled_callback():
                return None
                
            d_matrix = np.hypot(X - pt.x(), Y - pt.y())
            d_matrix = np.maximum(d_matrix, self.EPSILON) # Evitamos dividir por 0
            
            out_mask = d_matrix > buffer_zone
            in_mask = ~out_mask
            
            pt_score = np.zeros_like(d_matrix)
            
            if np.any(out_mask):
                pt_score[out_mask] = k / (d_matrix[out_mask] ** f)
                
            if np.any(in_mask):
                pt_score[in_mask] = (k * bg_f) / ((two_b - d_matrix[in_mask]) ** g)
                
            total_score += pt_score
            
            if progress_callback:
                try:
                    progress_callback(
                        int(((idx + 1) / total_points) * 100),
                        f"Procesando evento {idx + 1} de {total_points}..."
                    )
                except TypeError:
                    progress_callback(int(((idx + 1) / total_points) * 100))

        return total_score


    def run(self, layer, params, progress_callback=None, is_cancelled_callback=None):
        ok, msg = self.validate(layer, params)
        if not ok:
            return {"success": False, "message": msg}

        selected_only = params.get("selected_only", False)
        cell_size = params.get("cell_size", 100.0)
        margin = params.get("margin", 1000.0)
        buffer_zone = params.get("buffer_zone", 500.0)
        f = params.get("f", 1.2)
        g = params.get("g", 1.2)
        k = params.get("k", 1.0)
        output_name = params.get("output_name", "rossmo_output")

        points = self.get_valid_features(layer, selected_only=selected_only)

        if len(points) < 2:
            return {"success": False, "message": "No hay suficientes eventos válidos para Rossmo."}

        extent = self.build_extent(points, margin)
        rows, cols = self.compute_grid_size(extent, cell_size)
        total_cells = rows * cols

        if total_cells > self.MAX_GRID_CELLS:
            return {
                "success": False,
                "message": (
                    f"La grilla es demasiado grande ({total_cells} celdas). "
                    "Aumenta el tamaño de celda o reduce el margen."
                )
            }

        if progress_callback:
            try:
                progress_callback(5, "Iniciando vectorización espacial...")
            except TypeError:
                pass

        raw_scores = self.compute_score_surface(
            points=points,
            extent=extent,
            rows=rows,
            cols=cols,
            cell_size=cell_size,
            buffer_zone=buffer_zone,
            f=f,
            g=g,
            k=k,
            progress_callback=progress_callback,
            is_cancelled_callback=is_cancelled_callback
        )

        if raw_scores is None:
            return {"success": False, "message": "La ejecución de Rossmo fue cancelada por el usuario."}

        normalized_scores = normalize_array(raw_scores, nodata_value=-9999.0, constant_value=0.0)
        classes = reclassify_normalized_array_to_five_classes(normalized_scores, nodata_value=-9999.0)

        group_name = "Rossmo Results"

        raw_path, raw_raster = create_temp_raster_from_array(
            raw_scores,
            extent,
            layer.crs(),
            cell_size,
            cell_size,
            f"{output_name}_raw",
            gdal_type=gdal.GDT_Float32,
            nodata_value=-9999.0
        )

        if raw_raster is None:
            return {"success": False, "message": "No fue posible crear el raster bruto de Rossmo."}

        norm_path, norm_raster = create_temp_raster_from_array(
            normalized_scores,
            extent,
            layer.crs(),
            cell_size,
            cell_size,
            f"{output_name}_norm",
            gdal_type=gdal.GDT_Float32,
            nodata_value=-9999.0
        )

        if norm_raster is None:
            return {"success": False, "message": "No fue posible crear el raster normalizado de Rossmo."}

        add_raster_to_project(raw_raster, group_name=group_name)
        add_raster_to_project(norm_raster, group_name=group_name)
        style_rossmo_raster(norm_raster)

        class_path, class_raster = create_temp_raster_from_array(
            classes,
            extent,
            layer.crs(),
            cell_size,
            cell_size,
            f"{output_name}_class",
            gdal_type=gdal.GDT_Int16,
            nodata_value=0
        )

        vector_layer = None
        if class_raster is not None:
            vector_layer = polygonize_raster(
                class_path,
                f"{output_name}_poly",
                field_name="class_val",
                remove_zero_class=True
            )

            if vector_layer is not None:
                provider = vector_layer.dataProvider()

                if provider.fieldNameIndex("class_name") == -1:
                    from qgis.PyQt.QtCore import QVariant
                    from qgis.core import QgsField
                    provider.addAttributes([QgsField("class_name", QVariant.String)])
                    vector_layer.updateFields()

                idx_val = vector_layer.fields().indexFromName("class_val")
                idx_name = vector_layer.fields().indexFromName("class_name")

                label_map = {
                    1: "Muy bajo",
                    2: "Bajo",
                    3: "Medio",
                    4: "Alto",
                    5: "Muy alto"
                }

                updates = {}
                for feat in vector_layer.getFeatures():
                    class_val = feat[idx_val]
                    updates[feat.id()] = {
                        idx_name: label_map.get(class_val, "Sin clase")
                    }

                provider.changeAttributeValues(updates)
                add_vector_to_project(vector_layer, group_name=group_name)
                style_rossmo_vector_layer(vector_layer)

        raw_finite = raw_scores[(np.isfinite(raw_scores)) & (raw_scores != -9999.0)]
        norm_finite = normalized_scores[(np.isfinite(normalized_scores)) & (normalized_scores != -9999.0)]

        raw_min = float(np.min(raw_finite)) if raw_finite.size else 0.0
        raw_max = float(np.max(raw_finite)) if raw_finite.size else 0.0
        raw_mean = float(np.mean(raw_finite)) if raw_finite.size else 0.0

        norm_min = float(np.min(norm_finite)) if norm_finite.size else 0.0
        norm_max = float(np.max(norm_finite)) if norm_finite.size else 0.0

        outputs = [raw_raster.name(), norm_raster.name()]
        if vector_layer is not None:
            outputs.append(vector_layer.name())

        message = build_result_message(
            module_name="Fórmula de Rossmo (NumPy Engine)",
            layer_name=layer.name(),
            feature_count=len(points),
            parameters={
                "Tamaño de celda": cell_size,
                "Margen": margin,
                "Buffer zone": buffer_zone,
                "f (Decaimiento)": f,
                "g (Atracción interna)": g,
                "k (Constante empírica)": k,
                "Solo seleccionados": selected_only
            },
            outputs=outputs,
            extra_lines=[
                "Implementación: Aproximación matricial optimizada (Vectorización C).",
                f"Dimensiones de Grilla: {rows}x{cols} ({total_cells:,} celdas).",
                f"Score bruto [Min: {round(raw_min, 6)} | Max: {round(raw_max, 6)} | Med: {round(raw_mean, 6)}]",
                f"Score normalizado [Min: {round(norm_min, 6)} | Max: {round(norm_max, 6)}]"
            ]
        )

        return {"success": True, "message": message}