##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsGeometry

from ..core.validators import (
    validate_vector_point_layer,
    validate_projected_crs,
    validate_min_features,
    validate_group_field
)
from ..core.layer_utils import get_features
from ..core.geometry_utils import (
    calculate_mean_center,
    calculate_distances_from_center,
    create_square_from_center
)
from ..core.output_utils import (
    create_memory_layer,
    add_features, # UPGRADE: Inserción masiva
    add_layer_to_project
)
from ..core.style_utils import (
    style_gottlieb_layer,
    style_center_layer
)
from ..core.report_utils import build_result_message


class GottliebAnalysis:
    def validate(self, layer, params):
        ok, msg = validate_vector_point_layer(layer)
        if not ok:
            return False, msg

        ok, msg = validate_projected_crs(layer)
        if not ok:
            return False, msg

        selected_only = params.get("selected_only", False)
        ok, msg = validate_min_features(layer, min_count=2, selected_only=selected_only)
        if not ok:
            return False, msg

        group_field = params.get("group_field")
        ok, msg = validate_group_field(layer, group_field)
        if not ok:
            return False, msg

        # En Gottlieb el parámetro suele ser 'margin' (adicional al bounding box)
        margin = params.get("margin", 0.0)
        if margin < 0:
            return False, "El margen no puede ser negativo."

        return True, ""

    def run(self, layer, params):
        ok, msg = self.validate(layer, params)
        if not ok:
            return {"success": False, "message": msg}

        selected_only = params.get("selected_only", False)
        # Gottlieb no usa un radio/tamaño fijo, usa el Bounding Box + un Margen opcional
        margin = params.get("margin", 0.0) 
        output_name = params.get("output_name", "gottlieb_output")
        
        group_field = params.get("group_field")

        all_features = get_features(layer, selected_only=selected_only)
        if not all_features:
            return {"success": False, "message": "No hay entidades válidas para analizar."}

        groups = {}
        if group_field:
            for feat in all_features:
                val = feat[group_field]
                group_key = str(val) if val is not None else "Sin_Grupo"
                if group_key not in groups:
                    groups[group_key] = []
                groups[group_key].append(feat)
        else:
            groups["Todos"] = all_features

        polygon_layer = create_memory_layer(
            "Polygon",
            layer.crs(),
            output_name,
            [
                ("grupo", QVariant.String),
                ("half_size", QVariant.Double),
                ("margin", QVariant.Double),
                ("n_points", QVariant.Int)
            ]
        )

        center_layer = create_memory_layer(
            "Point",
            layer.crs(),
            f"{output_name}_center",
            [
                ("grupo", QVariant.String),
                ("x", QVariant.Double),
                ("y", QVariant.Double)
            ]
        )

        poly_features_data = []
        center_features_data = []
        
        failed_groups = []
        total_groups = len(groups)

        for group_name, features in groups.items():
            if len(features) < 2:
                failed_groups.append(group_name)
                continue

            center_point = calculate_mean_center(features)
            if center_point is None:
                failed_groups.append(group_name)
                continue

            distances_x = [abs(f.geometry().asPoint().x() - center_point.x()) for f in features]
            distances_y = [abs(f.geometry().asPoint().y() - center_point.y()) for f in features]
            
            max_dist_x = max(distances_x) if distances_x else 0.0
            max_dist_y = max(distances_y) if distances_y else 0.0
            
            auto_half_size = max(max_dist_x, max_dist_y)
            final_half_size = auto_half_size + margin

            polygon_geom = create_square_from_center(center_point, final_half_size)
            center_geom = QgsGeometry.fromPointXY(center_point)

            poly_features_data.append((polygon_geom, [group_name, float(final_half_size), float(margin), len(features)]))
            center_features_data.append((center_geom, [group_name, float(center_point.x()), float(center_point.y())]))

        if poly_features_data:
            add_features(polygon_layer, poly_features_data)
            add_features(center_layer, center_features_data)

            project_group_name = "Gottlieb Results"
            add_layer_to_project(polygon_layer, group_name=project_group_name)
            add_layer_to_project(center_layer, group_name=project_group_name)

            style_gottlieb_layer(polygon_layer)
            style_center_layer(center_layer)

        warnings = []
        if failed_groups:
            warnings.append(f"No se procesaron los grupos {failed_groups} (necesitan al menos 2 puntos).")
            
        outputs = []
        if poly_features_data:
            outputs = [polygon_layer.name(), center_layer.name()]
        else:
            return {"success": False, "message": "Ningún grupo tenía suficientes puntos para analizar."}

        message = build_result_message(
            module_name="Cuadrado de Gottlieb",
            layer_name=layer.name(),
            feature_count=len(all_features),
            parameters={
                "Campo de agrupación": group_field if group_field else "Ninguno",
                "Grupos analizados": len(poly_features_data),
                "Margen adicional": f"{margin} m",
                "Solo seleccionados": selected_only
            },
            outputs=outputs,
            warnings=warnings,
            extra_lines=[
                "Implementación: Cuadrado envolvente desde el Centro Medio.",
            ]
        )

        return {"success": True, "message": message}