##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


import math
from statistics import mean, median

from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsGeometry, QgsPointXY

from ..core.validators import (
    validate_vector_point_layer,
    validate_projected_crs,
    validate_min_features
)
from ..core.output_utils import (
    create_memory_layer,
    add_features, # UPGRADE: Usamos inserción masiva
    add_feature,
    add_layer_to_project
)
from ..core.style_utils import (
    style_jtc_line_layer,
    style_anchor_layer
)
from ..core.report_utils import build_result_message


class JourneyToCrimeAnalysis:
    def validate(self, event_layer, anchor_layer, params):
        ok, msg = validate_vector_point_layer(event_layer)
        if not ok:
            return False, f"Capa de eventos: {msg}"

        ok, msg = validate_vector_point_layer(anchor_layer)
        if not ok:
            return False, f"Capa de ancla: {msg}"

        ok, msg = validate_projected_crs(event_layer)
        if not ok:
            return False, f"Capa de eventos: {msg}"

        ok, msg = validate_projected_crs(anchor_layer)
        if not ok:
            return False, f"Capa de ancla: {msg}"

        if event_layer.crs() != anchor_layer.crs():
            return False, "La capa de eventos y la capa de ancla deben estar en el mismo CRS proyectado."

        selected_only = params.get("selected_only", False)

        ok, msg = validate_min_features(event_layer, min_count=1, selected_only=selected_only)
        if not ok:
            return False, msg

        selected_anchor_count = anchor_layer.selectedFeatureCount()
        total_anchor_count = anchor_layer.featureCount()

        if total_anchor_count < 1:
            return False, "La capa de ancla no tiene entidades."

        if selected_anchor_count > 1:
            return False, "Selecciona solo un punto ancla en la capa de ancla."

        if selected_anchor_count == 0 and total_anchor_count != 1:
            return False, "La capa de ancla debe tener una sola entidad o debes seleccionar exactamente una."

        return True, ""

    def _get_anchor_feature(self, anchor_layer):
        selected = anchor_layer.selectedFeatures()
        if len(selected) == 1:
            return selected[0]

        feats = list(anchor_layer.getFeatures())
        if len(feats) == 1:
            return feats[0]

        return None

    def run(self, event_layer, anchor_layer, params):
        ok, msg = self.validate(event_layer, anchor_layer, params)
        if not ok:
            return {"success": False, "message": msg}

        selected_only = params.get("selected_only", False)
        output_name = params.get("output_name", "jtc_output")
        
        distance_method = params.get("distance_method", "manhattan").lower()

        event_features = event_layer.selectedFeatures() if selected_only else list(event_layer.getFeatures())
        event_features = [f for f in event_features if f.geometry() and not f.geometry().isEmpty()]
        if not event_features:
            return {"success": False, "message": "No hay eventos válidos para analizar."}

        anchor_feature = self._get_anchor_feature(anchor_layer)
        if anchor_feature is None:
            return {"success": False, "message": "No fue posible determinar el punto ancla."}

        anchor_geom = anchor_feature.geometry()
        if anchor_geom.isEmpty():
            return {"success": False, "message": "La geometría del punto ancla es inválida o vacía."}

        if anchor_geom.isMultipart():
            anchor_point = anchor_geom.centroid().asPoint()
        else:
            anchor_point = anchor_geom.asPoint()
            
        anchor_xy = QgsPointXY(anchor_point.x(), anchor_point.y())

        line_layer = create_memory_layer(
            "LineString",
            event_layer.crs(),
            output_name,
            [
                ("event_id", QVariant.Int),
                ("anchor_id", QVariant.Int),
                ("distance_m", QVariant.Double),
                ("distance_km", QVariant.Double),
                ("rank_dist", QVariant.Int),
                ("event_x", QVariant.Double),
                ("event_y", QVariant.Double),
                ("anchor_x", QVariant.Double),
                ("anchor_y", QVariant.Double)
            ]
        )

        anchor_out_layer = create_memory_layer(
            "Point",
            event_layer.crs(),
            f"{output_name}_anchor",
            [
                ("anchor_id", QVariant.Int),
                ("x", QVariant.Double),
                ("y", QVariant.Double)
            ]
        )

        distance_records = []

        for feat in event_features:
            geom = feat.geometry()
            if geom.isMultipart():
                event_point = geom.centroid().asPoint()
            else:
                event_point = geom.asPoint()
                
            event_xy = QgsPointXY(event_point.x(), event_point.y())

            # =========================================================
            # Lógica Euclidiana vs Manhattan
            # =========================================================
            if distance_method == "manhattan":
                dist_m = abs(anchor_xy.x() - event_xy.x()) + abs(anchor_xy.y() - event_xy.y())
                
                corner_xy = QgsPointXY(event_xy.x(), anchor_xy.y())
                line_geom = QgsGeometry.fromPolylineXY([anchor_xy, corner_xy, event_xy])
            else:
                dx = event_xy.x() - anchor_xy.x()
                dy = event_xy.y() - anchor_xy.y()
                dist_m = math.hypot(dx, dy)
                line_geom = QgsGeometry.fromPolylineXY([anchor_xy, event_xy])

            distance_records.append({
                "event_id": int(feat.id()),
                "line_geom": line_geom,
                "dist_m": float(dist_m),
                "event_x": float(event_xy.x()),
                "event_y": float(event_xy.y())
            })

        if not distance_records:
            return {"success": False, "message": "No fue posible construir registros de distancia válidos."}

        sorted_records = sorted(distance_records, key=lambda x: x["dist_m"])
        
        features_to_add = []

        for rank, record in enumerate(sorted_records, start=1):
            attrs = [
                record["event_id"],
                int(anchor_feature.id()),
                record["dist_m"],
                float(record["dist_m"] / 1000.0),
                int(rank),
                record["event_x"],
                record["event_y"],
                float(anchor_xy.x()),
                float(anchor_xy.y())
            ]
            features_to_add.append((record["line_geom"], attrs))

        add_features(line_layer, features_to_add)

        add_feature(
            anchor_out_layer,
            QgsGeometry.fromPointXY(anchor_xy),
            [
                int(anchor_feature.id()),
                float(anchor_xy.x()),
                float(anchor_xy.y())
            ]
        )

        group_name = "Journey To Crime Results"
        add_layer_to_project(line_layer, group_name=group_name)
        add_layer_to_project(anchor_out_layer, group_name=group_name)

        style_jtc_line_layer(line_layer)
        style_anchor_layer(anchor_out_layer)

        dists = [r["dist_m"] for r in sorted_records]
        method_label = "Manhattan (Bloques urbanos)" if distance_method == "manhattan" else "Euclidiana (Línea recta)"

        message = build_result_message(
            module_name="Journey to Crime",
            layer_name=event_layer.name(),
            feature_count=len(event_features),
            parameters={
                "Método de distancia": method_label,
                "Solo seleccionados": selected_only
            },
            outputs=[
                line_layer.name(),
                anchor_out_layer.name()
            ],
            extra_lines=[
                f"<b>Cálculo:</b> {method_label} plana en CRS proyectado.",
                f"Distancia mínima: {round(min(dists), 3)} m",
                f"Distancia máxima: {round(max(dists), 3)} m",
                f"Distancia media: {round(mean(dists), 3)} m",
                f"Distancia mediana: {round(median(dists), 3)} m"
            ]
        )

        return {"success": True, "message": message}