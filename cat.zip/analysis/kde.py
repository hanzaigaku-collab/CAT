##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


import numpy as np
from osgeo import gdal
from qgis.core import QgsRectangle

from ..core.validators import (
    validate_vector_point_layer,
    validate_projected_crs,
    validate_min_features
)
from ..core.raster_utils import (
    create_temp_raster_from_array,
    add_raster_to_project,
    normalize_array
)
from ..core.report_utils import build_result_message

class KDEAnalysis:
    def validate(self, layer, params):
        ok, msg = validate_vector_point_layer(layer)
        if not ok: return False, msg
        ok, msg = validate_projected_crs(layer)
        if not ok: return False, msg
        
        radius = params.get("radius", 0.0)
        if radius <= 0: return False, "El radio de búsqueda debe ser mayor a 0."
        
        return True, ""

    def run(self, layer, params, progress_callback=None):
        ok, msg = self.validate(layer, params)
        if not ok: return {"success": False, "message": msg}

        radius = params.get("radius", 1000.0)
        cell_size = params.get("cell_size", 50.0)
        output_name = params.get("output_name", "kde_output")

        features = list(layer.selectedFeatures()) if params.get("selected_only") else list(layer.getFeatures())
        points = [f.geometry().centroid().asPoint() for f in features if f.geometry()]
        
        xs = [p.x() for p in points]
        ys = [p.y() for p in points]
        extent = QgsRectangle(min(xs) - radius, min(ys) - radius, max(xs) + radius, max(ys) + radius)
        
        rows = int(extent.height() / cell_size)
        cols = int(extent.width() / cell_size)
        
        x_c = extent.xMinimum() + (np.arange(cols) + 0.5) * cell_size
        y_c = extent.yMaximum() - (np.arange(rows) + 0.5) * cell_size
        X, Y = np.meshgrid(x_c, y_c)
        
        kde_map = np.zeros((rows, cols), dtype=np.float32)
        radius_sq = radius ** 2
        
        for i, pt in enumerate(points):
            dx = X - pt.x()
            dy = Y - pt.y()
            d2 = dx**2 + dy**2
            
            mask = d2 < radius_sq
            kde_map[mask] += (3.0 / np.pi) * (1.0 - d2[mask] / radius_sq) ** 2
            
            if progress_callback: progress_callback(int((i/len(points))*100))

        path, raster = create_temp_raster_from_array(
            kde_map, extent, layer.crs(), cell_size, cell_size, output_name
        )
        add_raster_to_project(raster, group_name="KDE Results")
        
        return {"success": True, "message": f"KDE generado con radio {radius}m."}