##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


import math

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsFeature,
    QgsProject,
    QgsVectorLayer,
    QgsField,
    QgsSpatialIndex,
    QgsRectangle
)

from ..core.validators import (
    validate_vector_polygon_layer,
    validate_projected_crs,
    validate_min_features,
    validate_numeric_field
)
from ..core.style_utils import style_getis_ord_layer
from ..core.report_utils import build_result_message
from ..core.output_utils import add_layer_to_project # UPGRADE: para las carpetas


class GetisOrdGiAnalysis:
    def validate(self, layer, params):
        ok, msg = validate_vector_polygon_layer(layer)
        if not ok:
            return False, msg

        ok, msg = validate_projected_crs(layer)
        if not ok:
            return False, msg

        selected_only = params.get("selected_only", False)
        ok, msg = validate_min_features(layer, min_count=3, selected_only=selected_only)
        if not ok:
            return False, msg

        field_name = params.get("value_field")
        ok, msg = validate_numeric_field(layer, field_name)
        if not ok:
            return False, msg

        distance_band = params.get("distance_band", 1000.0)
        if distance_band <= 0:
            return False, "La distancia de vecindad debe ser mayor que 0."

        return True, ""

    def _normal_cdf(self, z):
        return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))

    def _p_value_from_z(self, z):
        # p-value bilateral
        return 2.0 * (1.0 - self._normal_cdf(abs(z)))

    def _classify_z(self, z):
        if z >= 2.58:
            return "Hotspot 99%"
        elif z >= 1.96:
            return "Hotspot 95%"
        elif z >= 1.65:
            return "Hotspot 90%"
        elif z <= -2.58:
            return "Coldspot 99%"
        elif z <= -1.96:
            return "Coldspot 95%"
        elif z <= -1.65:
            return "Coldspot 90%"
        return "No significativo"

    def run(self, layer, params):
        ok, msg = self.validate(layer, params)
        if not ok:
            return {"success": False, "message": msg}

        selected_only = params.get("selected_only", False)
        value_field = params.get("value_field")
        distance_band = params.get("distance_band", 1000.0)
        include_self = params.get("include_self", True)
        output_name = params.get("output_name", "getis_ord_gi_output")

        input_features = list(layer.selectedFeatures()) if selected_only else list(layer.getFeatures())
        input_features = [f for f in input_features if f.geometry() and not f.geometry().isEmpty()]

        if len(input_features) < 3:
            return {"success": False, "message": "No hay suficientes polígonos válidos para ejecutar Getis-Ord local."}

        values = []
        centroids = []
        valid_features = []
        
        spatial_index = QgsSpatialIndex()
        centroid_dict = {}
        value_dict = {}

        for i, feat in enumerate(input_features):
            value = feat[value_field]
            if value is None:
                continue

            try:
                numeric_value = float(value)
            except Exception:
                continue

            centroid_geom = feat.geometry().centroid()
            if centroid_geom.isEmpty():
                continue

            pt = centroid_geom.asPoint()
            
            values.append(numeric_value)
            centroids.append(pt)
            valid_features.append(feat)
            
            centroid_dict[i] = pt
            value_dict[i] = numeric_value
            
            idx_feat = QgsFeature(i)
            idx_feat.setGeometry(centroid_geom)
            spatial_index.addFeature(idx_feat)

        n = len(valid_features)
        if n < 3:
            return {"success": False, "message": "No hay suficientes entidades con geometría y valor numérico válido."}

        global_mean = sum(values) / n
        sum_sq = sum(v ** 2 for v in values)
        variance = (sum_sq / n) - (global_mean ** 2)

        if variance <= 0:
            return {
                "success": False,
                "message": "La varianza global del campo es cero o inválida. El estadístico local no puede calcularse."
            }

        global_std = math.sqrt(variance)

        out_layer = QgsVectorLayer(
            f"Polygon?crs={layer.crs().authid()}",
            output_name,
            "memory"
        )
        provider = out_layer.dataProvider()
        provider.addAttributes(list(layer.fields()))
        provider.addAttributes([
            QgsField("gi_zscore", QVariant.Double),
            QgsField("gi_pvalue", QVariant.Double),
            QgsField("gi_class", QVariant.String),
            QgsField("gi_nbrs", QVariant.Int),
            QgsField("gi_valid", QVariant.Int)
        ])
        out_layer.updateFields()

        output_features = []
        invalid_neighbor_cases = 0

        for i, feat_i in enumerate(valid_features):
            c_pt = centroids[i]
            
            # 1. Crear caja de búsqueda (Bounding Box) alrededor del centroide
            search_rect = QgsRectangle(
                c_pt.x() - distance_band,
                c_pt.y() - distance_band,
                c_pt.x() + distance_band,
                c_pt.y() + distance_band
            )
            
            candidate_ids = spatial_index.intersects(search_rect)
            
            sum_w = 0.0
            weighted_sum = 0.0
            
            for j in candidate_ids:
                if i == j:
                    wij = 1.0 if include_self else 0.0
                else:
                    o_pt = centroid_dict[j]
                    # Pitágoras puro es más rápido que QGIS
                    d = math.hypot(c_pt.x() - o_pt.x(), c_pt.y() - o_pt.y())
                    wij = 1.0 if d <= distance_band else 0.0

                if wij > 0:
                    sum_w += wij
                    weighted_sum += wij * value_dict[j]

            sum_w_sq = sum_w

            gi_valid = 1
            denom_term = ((n * sum_w_sq) - (sum_w ** 2)) / (n - 1) if n > 1 else 0.0

            if denom_term <= 0:
                z_score = 0.0
                p_value = 1.0
                gi_valid = 0
                invalid_neighbor_cases += 1
            else:
                denominator = global_std * math.sqrt(denom_term)
                if denominator <= 0:
                    z_score = 0.0
                    p_value = 1.0
                    gi_valid = 0
                    invalid_neighbor_cases += 1
                else:
                    numerator = weighted_sum - (global_mean * sum_w)
                    z_score = numerator / denominator
                    p_value = self._p_value_from_z(z_score)

            gi_class = self._classify_z(z_score) if gi_valid == 1 else "No significativo"
            n_neighbors = int(sum_w)

            out_feat = QgsFeature(out_layer.fields())
            out_feat.setGeometry(feat_i.geometry())
            attrs = feat_i.attributes() + [
                float(z_score),
                float(p_value),
                gi_class,
                n_neighbors,
                gi_valid
            ]
            out_feat.setAttributes(attrs)
            output_features.append(out_feat)

        provider.addFeatures(output_features)
        out_layer.updateExtents()
        
        add_layer_to_project(out_layer, group_name="Hotspot Results")
        style_getis_ord_layer(out_layer)

        z_scores = [f["gi_zscore"] for f in out_layer.getFeatures()]
        hot_count = sum(1 for z in z_scores if z is not None and z >= 1.65)
        cold_count = sum(1 for z in z_scores if z is not None and z <= -1.65)

        message = build_result_message(
            module_name="Getis-Ord local (Gi / Gi*)",
            layer_name=layer.name(),
            feature_count=n,
            parameters={
                "Campo numérico": value_field,
                "Distancia de vecindad": f"{distance_band} m",
                "Incluir auto-vecino": include_self,
                "Solo seleccionados": selected_only
            },
            outputs=[out_layer.name()],
            extra_lines=[
                "<b>Implementación:</b> Distancia fija euclidiana entre centroides con pesos binarios (Spatial Index Optimizado).",
                "p-value reportado: bilateral.",
                f"Media global: {round(global_mean, 6)}",
                f"Desviación estándar global: {round(global_std, 6)}",
                f"Hotspots (z >= 1.65): {hot_count}",
                f"Coldspots (z <= -1.65): {cold_count}",
                f"Entidades con vecindad no válida (Aisladas): {invalid_neighbor_cases}"
            ]
        )

        return {"success": True, "message": message}