# CAT! Cartographic Assistant Tool-CAT

Pide consejo al Gran Gato Cósmico... Quizás te ayude... Quizás! CAT! es un plugin experimental NO OFICIAL para QGIS diseñado para asistir en procesos de geoperfilación criminal y análisis de patrones delictivos.

## 

## Upgrades:

* **Motor Vectorizado (NumPy/GDAL):** Optimización masiva de rendimiento en Rossmo y RTM mediante álgebra de matrices.
* **Eficiencia Espacial:** Implementación de Índices Espaciales y técnica *Splatting* para evitar el bloqueo del software en conjuntos de datos grandes.
* **Interfaz Nativa:** Migración a widgets de QGIS para soporte total de Dark Mode y actualización automática de capas.
* **Soporte de Agrupación:** Todos los módulos ahora permiten el análisis segmentado por grupos (ej. Modus Operandi o Banda Criminal).
* **Cálculo Manhattan:** Opción para medir trayectorias urbanas en el módulo *Journey to Crime*.
* **Inserción Masiva (Bulk Insert):** Mejora drástica en la velocidad de escritura de resultados en memoria.

## 

## Módulos:

* **Círculos de Canter:** Estimación de radio de influencia.
* **Rectángulos de Gottlieb:** Cuadrados de envolvente para perfilación geográfica.
* **Journey to Crime:** Análisis de origen-destino (Euclidiana y Manhattan).
* **Fórmula de Rossmo:** Priorización espacial mediante aproximación raster.
* **Near Repeat Calculator:** Detección de pares espacio-temporales con ventana deslizante.
* ***Getis-Ord Gi*\***: Identificación estadística de Hotspots/Coldspots.
* **Risk Terrain Modelling:** Modelado de riesgo relativo basado en factores geográficos.
* **KDE:** Estimación de densidad mediante función Kernel Quartic para identificar centros de gravedad de eventos.



## Requisitos:

* QGIS 3.40+
* Numpy y GDAL (incluidos en la instalación estándar de QGIS).
* Capas en CRS proyectado (coordenadas métricas).

