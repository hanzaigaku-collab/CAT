##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QComboBox, QCheckBox,
    QTabWidget, QWidget, QPushButton, QDoubleSpinBox, QMessageBox,
    QGroupBox, QLabel, QTextEdit, QFileDialog, QFrame, QTextBrowser,
    QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView, QProgressDialog,
    QApplication
)
from qgis.PyQt.QtCore import QVariant, Qt, QDateTime
from qgis.PyQt.QtGui import QTextCursor

# UPGRADE: Importamos los modelos y widgets nativos de QGIS
from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes, QgsMapLayerProxyModel, QgsFieldProxyModel
from qgis.gui import QgsMapLayerComboBox, QgsFieldComboBox

from ..analysis.canter import CanterAnalysis
from ..analysis.gottlieb import GottliebAnalysis
from ..analysis.journey_to_crime import JourneyToCrimeAnalysis
from ..analysis.rossmo import RossmoAnalysis
from ..analysis.near_repeat import NearRepeatAnalysis
from ..analysis.getis_ord_gi import GetisOrdGiAnalysis
from ..analysis.rtm import RTMAnalysis
from ..core.naming_utils import build_output_name
from ..analysis.kde import KDEAnalysis


class CatMainDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("GeoProfileQGIS")
        self.resize(900, 900)

        self.rtm_factors = []

        self._build_ui()

    # =========================================================
    # UI principal
    # =========================================================
    def _build_ui(self):
        self.main_layout = QVBoxLayout()
        self.setLayout(self.main_layout)

        # -----------------------------
        # Configuración general (Nativa QGIS)
        # -----------------------------
        general_group = QGroupBox("Configuración general")
        general_layout = QFormLayout()

        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.layer_combo.setToolTip("Selecciona la capa de incidentes puntuales.")

        self.anchor_layer_combo = QgsMapLayerComboBox()
        self.anchor_layer_combo.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.anchor_layer_combo.setToolTip("Selecciona la capa de punto ancla para Journey to Crime.")

        self.group_field_combo = QgsFieldComboBox()
        self.group_field_combo.setAllowEmptyFieldName(True)
        self.group_field_combo.setLayer(self.layer_combo.currentLayer())
        
        self.layer_combo.layerChanged.connect(self.group_field_combo.setLayer)

        self.selected_only_checkbox = QCheckBox("Usar solo eventos seleccionados")
        self.selected_only_checkbox.setToolTip("Si se activa, el análisis usará únicamente las entidades seleccionadas.")

        general_layout.addRow("Capa de incidentes:", self.layer_combo)
        general_layout.addRow("Capa de ancla:", self.anchor_layer_combo)
        general_layout.addRow("Campo de agrupación:", self.group_field_combo)
        general_layout.addRow("", self.selected_only_checkbox)

        general_group.setLayout(general_layout)
        self.main_layout.addWidget(general_group)

        # -----------------------------
        # Tabs
        # -----------------------------
        self.tabs = QTabWidget()
        self.tabs.addTab(self.create_canter_tab(), "Canter")
        self.tabs.addTab(self.create_gottlieb_tab(), "Gottlieb")
        self.tabs.addTab(self.create_jtc_tab(), "Journey to Crime")
        self.tabs.addTab(self.create_rossmo_tab(), "Rossmo")
        self.tabs.addTab(self.create_near_repeat_tab(), "Near Repeat")
        self.tabs.addTab(self.create_gi_tab(), "Getis-Ord Gi*")
        self.tabs.addTab(self.create_rtm_tab(), "RTM")
        self.tabs.addTab(self.create_kde_tab(), "KDE")
        self.tabs.addTab(self.create_help_tab(), "Metodología")
        self.tabs.addTab(self.create_about_tab(), "Acerca de")
        self.main_layout.addWidget(self.tabs)

        # -----------------------------
        # Panel de resultados
        # -----------------------------
        results_group = QGroupBox("Resultados / Log")
        results_layout = QVBoxLayout()
        results_group.setLayout(results_layout)

        self.results_text = QTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setAcceptRichText(True)
        self.results_text.setStyleSheet("""
            QTextEdit {
                font-family: Consolas, 'Courier New', monospace;
                font-size: 10pt;
            }
        """)

        results_layout.addWidget(self.results_text)

        result_buttons_layout = QHBoxLayout()

        self.copy_results_button = QPushButton("Copiar resultados")
        self.copy_results_button.clicked.connect(self.copy_results)

        self.save_results_button = QPushButton("Guardar log")
        self.save_results_button.clicked.connect(self.save_results)
        self.save_results_button.setToolTip("Guarda el contenido del panel en un archivo TXT.")

        self.save_html_button = QPushButton("Guardar HTML")
        self.save_html_button.clicked.connect(self.save_results_html)
        self.save_html_button.setToolTip("Guarda el panel de resultados con formato HTML.")

        self.clear_results_button = QPushButton("Limpiar panel")
        self.clear_results_button.clicked.connect(self.clear_results)

        result_buttons_layout.addWidget(self.copy_results_button)
        result_buttons_layout.addWidget(self.save_results_button)
        result_buttons_layout.addWidget(self.save_html_button)
        result_buttons_layout.addWidget(self.clear_results_button)
        result_buttons_layout.addStretch()

        results_layout.addLayout(result_buttons_layout)
        self.main_layout.addWidget(results_group)

        # -----------------------------
        # Barra de estado
        # -----------------------------
        status_frame = QFrame()
        status_frame.setFrameShape(QFrame.StyledPanel)
        status_layout = QHBoxLayout()
        status_frame.setLayout(status_layout)

        self.status_label = QLabel("Listo")
        self.status_label.setStyleSheet("""
            QLabel {
                color: #444;
                padding: 4px;
            }
        """)

        status_layout.addWidget(self.status_label)
        self.main_layout.addWidget(status_frame)

    # =========================================================
    # Tabs
    # =========================================================
    def create_canter_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        help_label = QLabel(
            "Genera un círculo de análisis basado en eventos puntuales. "
            "Requiere una capa de puntos en CRS proyectado."
        )
        help_label.setWordWrap(True)
        layout.addWidget(help_label)

        form = QFormLayout()

        self.canter_radius_spin = QDoubleSpinBox()
        self.canter_radius_spin.setRange(0, 10000000)
        self.canter_radius_spin.setValue(0.0)
        self.canter_radius_spin.setDecimals(2)
        self.canter_radius_spin.setSuffix(" m")
        self.canter_radius_spin.setToolTip(
            "Si el valor es 0, el plugin estimará un radio sugerido a partir de los eventos."
        )

        self.canter_method_combo = QComboBox()
        self.canter_method_combo.addItems(["max", "mean", "median", "p90"])
        self.canter_method_combo.setCurrentText("max")
        self.canter_method_combo.setToolTip(
            "Método para estimar el radio automático: "
            "max = cobertura total, mean = promedio, median = robusto, p90 = percentil 90."
        )

        form.addRow("Radio manual:", self.canter_radius_spin)
        layout.addLayout(form)

        run_button = QPushButton("Ejecutar Canter")
        run_button.clicked.connect(self.run_canter)
        layout.addWidget(run_button)

        layout.addStretch()
        return tab

    def create_gottlieb_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        help_label = QLabel(
            "Genera un cuadrado envolvente alineado a ejes a partir del patrón espacial observado "
            "usando el bounding box de los eventos. Requiere una capa de puntos en CRS proyectado."
        )
        help_label.setWordWrap(True)
        layout.addWidget(help_label)

        form = QFormLayout()

        self.gottlieb_margin_spin = QDoubleSpinBox()
        self.gottlieb_margin_spin.setRange(0, 1000000)
        self.gottlieb_margin_spin.setValue(0.0)
        self.gottlieb_margin_spin.setDecimals(2)
        self.gottlieb_margin_spin.setSuffix(" m")
        self.gottlieb_margin_spin.setToolTip(
            "Margen opcional añadido al cuadrado envolvente calculado desde el bounding box."
        ) 

        form.addRow("Margen:", self.gottlieb_margin_spin)
        layout.addLayout(form)

        run_button = QPushButton("Ejecutar Gottlieb")
        run_button.clicked.connect(self.run_gottlieb)
        layout.addWidget(run_button)

        layout.addStretch()
        return tab

    def create_jtc_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        help_label = QLabel(
            "Journey to Crime: calcula distancias y líneas entre un punto ancla y múltiples eventos. "
            "Usa una capa de eventos y una capa de ancla con un único punto seleccionado o una sola entidad."
        )
        help_label.setWordWrap(True)
        layout.addWidget(help_label)

        form = QFormLayout()
        self.jtc_method_combo = QComboBox()
        self.jtc_method_combo.addItems(["Manhattan (Bloques urbanos)", "Euclidiana (Línea recta)"])
        self.jtc_method_combo.setToolTip("Método matemático para medir distancias y trazar el movimiento.")
        form.addRow("Tipo de distancia:", self.jtc_method_combo)
        
        layout.addLayout(form)

        run_button = QPushButton("Ejecutar Journey to Crime")
        run_button.clicked.connect(self.run_jtc)
        layout.addWidget(run_button)

        layout.addStretch()
        return tab

    def create_rossmo_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        help_label = QLabel(
            "Rossmo genera una superficie raster normalizada de priorización espacial y una "
            "vectorización reclasificada. Requiere puntos en CRS proyectado."
        )
        help_label.setWordWrap(True)
        layout.addWidget(help_label)

        form = QFormLayout()

        self.rossmo_cell_size_spin = QDoubleSpinBox()
        self.rossmo_cell_size_spin.setRange(1, 1000000)
        self.rossmo_cell_size_spin.setValue(100.0)
        self.rossmo_cell_size_spin.setDecimals(2)
        self.rossmo_cell_size_spin.setSuffix(" m")
        self.rossmo_cell_size_spin.setToolTip("Tamaño de celda del raster de salida.")

        self.rossmo_margin_spin = QDoubleSpinBox()
        self.rossmo_margin_spin.setRange(0, 1000000)
        self.rossmo_margin_spin.setValue(1000.0)
        self.rossmo_margin_spin.setDecimals(2)
        self.rossmo_margin_spin.setSuffix(" m")
        self.rossmo_margin_spin.setToolTip("Margen añadido al extent de los eventos.")

        self.rossmo_buffer_spin = QDoubleSpinBox()
        self.rossmo_buffer_spin.setRange(1, 1000000)
        self.rossmo_buffer_spin.setValue(500.0)
        self.rossmo_buffer_spin.setDecimals(2)
        self.rossmo_buffer_spin.setSuffix(" m")
        self.rossmo_buffer_spin.setToolTip("Buffer zone del modelo de Rossmo.")

        self.rossmo_f_spin = QDoubleSpinBox()
        self.rossmo_f_spin.setRange(0.01, 100.0)
        self.rossmo_f_spin.setValue(1.2)
        self.rossmo_f_spin.setDecimals(3)
        self.rossmo_f_spin.setToolTip("Exponente f del modelo.")

        self.rossmo_g_spin = QDoubleSpinBox()
        self.rossmo_g_spin.setRange(0.01, 100.0)
        self.rossmo_g_spin.setValue(1.2)
        self.rossmo_g_spin.setDecimals(3)
        self.rossmo_g_spin.setToolTip("Exponente g del modelo.")

        self.rossmo_k_spin = QDoubleSpinBox()
        self.rossmo_k_spin.setRange(0.01, 1000000.0)
        self.rossmo_k_spin.setValue(1.0)
        self.rossmo_k_spin.setDecimals(3)
        self.rossmo_k_spin.setToolTip("Constante k del modelo.")

        form.addRow("Tamaño de celda:", self.rossmo_cell_size_spin)
        form.addRow("Margen:", self.rossmo_margin_spin)
        form.addRow("Buffer zone:", self.rossmo_buffer_spin)
        form.addRow("f:", self.rossmo_f_spin)
        form.addRow("g:", self.rossmo_g_spin)
        form.addRow("k:", self.rossmo_k_spin)

        layout.addLayout(form)

        run_button = QPushButton("Ejecutar Rossmo")
        run_button.clicked.connect(self.run_rossmo)
        layout.addWidget(run_button)

        layout.addStretch()
        return tab

    def create_near_repeat_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        help_label = QLabel(
            "Near Repeat detecta pares de eventos cercanos en espacio y tiempo. "
            "Requiere una capa de puntos y un campo de fecha/hora interpretable."
        )
        help_label.setWordWrap(True)
        layout.addWidget(help_label)

        form = QFormLayout()

        self.near_repeat_time_field_combo = QgsFieldComboBox()
        self.near_repeat_time_field_combo.setLayer(self.layer_combo.currentLayer())
        self.layer_combo.layerChanged.connect(self.near_repeat_time_field_combo.setLayer)
        self.near_repeat_time_field_combo.setToolTip("Selecciona el campo temporal.")

        self.near_repeat_spatial_spin = QDoubleSpinBox()
        self.near_repeat_spatial_spin.setRange(0.01, 1000000.0)
        self.near_repeat_spatial_spin.setValue(200.0)
        self.near_repeat_spatial_spin.setDecimals(2)
        self.near_repeat_spatial_spin.setSuffix(" m")
        self.near_repeat_spatial_spin.setToolTip("Umbral de distancia espacial.")

        self.near_repeat_temporal_spin = QDoubleSpinBox()
        self.near_repeat_temporal_spin.setRange(0.01, 1000000.0)
        self.near_repeat_temporal_spin.setValue(7.0)
        self.near_repeat_temporal_spin.setDecimals(2)
        self.near_repeat_temporal_spin.setToolTip("Umbral temporal.")

        self.near_repeat_unit_combo = QComboBox()
        self.near_repeat_unit_combo.addItems(["Días", "Horas"])
        self.near_repeat_unit_combo.setToolTip("Unidad temporal del umbral.")

        form.addRow("Campo temporal:", self.near_repeat_time_field_combo)
        form.addRow("Umbral espacial:", self.near_repeat_spatial_spin)
        form.addRow("Umbral temporal:", self.near_repeat_temporal_spin)
        form.addRow("Unidad temporal:", self.near_repeat_unit_combo)

        layout.addLayout(form)

        run_button = QPushButton("Ejecutar Near Repeat")
        run_button.clicked.connect(self.run_near_repeat)
        layout.addWidget(run_button)

        layout.addStretch()
        return tab

    def create_gi_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        help_label = QLabel(
            "Getis-Ord Gi* identifica hotspots y coldspots locales sobre una capa poligonal "
            "a partir de un campo numérico."
        )
        help_label.setWordWrap(True)
        layout.addWidget(help_label)

        form = QFormLayout()

        self.gi_layer_combo = QgsMapLayerComboBox()
        self.gi_layer_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.gi_layer_combo.setToolTip("Selecciona una capa poligonal.")

        self.gi_field_combo = QgsFieldComboBox()
        self.gi_field_combo.setFilters(QgsFieldProxyModel.Numeric)
        self.gi_field_combo.setLayer(self.gi_layer_combo.currentLayer())
        self.gi_layer_combo.layerChanged.connect(self.gi_field_combo.setLayer)
        self.gi_field_combo.setToolTip("Selecciona un campo numérico.")

        self.gi_distance_spin = QDoubleSpinBox()
        self.gi_distance_spin.setRange(0.01, 10000000.0)
        self.gi_distance_spin.setValue(1000.0)
        self.gi_distance_spin.setDecimals(2)
        self.gi_distance_spin.setSuffix(" m")
        self.gi_distance_spin.setToolTip("Distancia fija de vecindad.")

        self.gi_include_self_checkbox = QCheckBox("Incluir auto-vecino")
        self.gi_include_self_checkbox.setChecked(True)
        self.gi_include_self_checkbox.setToolTip("Si se activa, cada polígono se incluye a sí mismo en el cálculo.")

        form.addRow("Capa poligonal:", self.gi_layer_combo)
        form.addRow("Campo numérico:", self.gi_field_combo)
        form.addRow("Distancia de vecindad:", self.gi_distance_spin)
        form.addRow("", self.gi_include_self_checkbox)

        layout.addLayout(form)

        run_button = QPushButton("Ejecutar Getis-Ord Gi*")
        run_button.clicked.connect(self.run_gi)
        layout.addWidget(run_button)

        layout.addStretch()
        return tab

    def create_rtm_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        help_label = QLabel(
            "RTM combina hasta 3 factores geográficos en una superficie raster de riesgo relativo. "
            "Todos los factores deben estar en el mismo CRS proyectado."
        )
        help_label.setWordWrap(True)
        layout.addWidget(help_label)

        factor_group = QGroupBox("Agregar factor")
        factor_form = QFormLayout()

        self.rtm_layer_combo = QgsMapLayerComboBox()
        self.rtm_layer_combo.setToolTip("Selecciona la capa del factor.")

        self.rtm_factor_name_edit = QLineEdit()
        self.rtm_factor_name_edit.setPlaceholderText("Ej. Bares, lotes baldíos, escuelas")
        self.rtm_factor_name_edit.setToolTip("Nombre descriptivo del factor.")

        self.rtm_influence_combo = QComboBox()
        self.rtm_influence_combo.addItems(["buffer", "decay"])
        self.rtm_influence_combo.setToolTip("Tipo de influencia espacial.")

        self.rtm_distance_spin = QDoubleSpinBox()
        self.rtm_distance_spin.setRange(0.01, 10000000.0)
        self.rtm_distance_spin.setValue(500.0)
        self.rtm_distance_spin.setDecimals(2)
        self.rtm_distance_spin.setSuffix(" m")
        self.rtm_distance_spin.setToolTip("Distancia máxima de influencia del factor.")

        self.rtm_weight_spin = QDoubleSpinBox()
        self.rtm_weight_spin.setRange(0.0, 1000000.0)
        self.rtm_weight_spin.setValue(1.0)
        self.rtm_weight_spin.setDecimals(3)
        self.rtm_weight_spin.setToolTip("Peso del factor en la combinación final.")

        add_factor_button = QPushButton("Agregar factor")
        add_factor_button.clicked.connect(self.add_rtm_factor)

        factor_form.addRow("Capa:", self.rtm_layer_combo)
        factor_form.addRow("Nombre del factor:", self.rtm_factor_name_edit)
        factor_form.addRow("Influencia:", self.rtm_influence_combo)
        factor_form.addRow("Distancia:", self.rtm_distance_spin)
        factor_form.addRow("Peso:", self.rtm_weight_spin)
        factor_form.addRow("", add_factor_button)

        factor_group.setLayout(factor_form)
        layout.addWidget(factor_group)

        self.rtm_table = QTableWidget(0, 5)
        self.rtm_table.setHorizontalHeaderLabels(["Nombre", "Capa", "Influencia", "Distancia", "Peso"])
        self.rtm_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.rtm_table.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.rtm_table)

        table_buttons = QHBoxLayout()

        remove_factor_button = QPushButton("Eliminar factor seleccionado")
        remove_factor_button.clicked.connect(self.remove_selected_rtm_factor)

        clear_factors_button = QPushButton("Limpiar factores")
        clear_factors_button.clicked.connect(self.clear_rtm_factors)

        table_buttons.addWidget(remove_factor_button)
        table_buttons.addWidget(clear_factors_button)
        table_buttons.addStretch()
        layout.addLayout(table_buttons)

        global_group = QGroupBox("Parámetros globales RTM")
        global_form = QFormLayout()

        self.rtm_cell_size_spin = QDoubleSpinBox()
        self.rtm_cell_size_spin.setRange(1, 1000000)
        self.rtm_cell_size_spin.setValue(100.0)
        self.rtm_cell_size_spin.setDecimals(2)
        self.rtm_cell_size_spin.setSuffix(" m")
        self.rtm_cell_size_spin.setToolTip("Tamaño de celda del raster RTM.")

        self.rtm_margin_spin = QDoubleSpinBox()
        self.rtm_margin_spin.setRange(0, 1000000)
        self.rtm_margin_spin.setValue(1000.0)
        self.rtm_margin_spin.setDecimals(2)
        self.rtm_margin_spin.setSuffix(" m")
        self.rtm_margin_spin.setToolTip("Margen añadido al extent conjunto de los factores.")

        global_form.addRow("Tamaño de celda:", self.rtm_cell_size_spin)
        global_form.addRow("Margen:", self.rtm_margin_spin)

        global_group.setLayout(global_form)
        layout.addWidget(global_group)

        run_button = QPushButton("Ejecutar RTM")
        run_button.clicked.connect(self.run_rtm)
        layout.addWidget(run_button)

        layout.addStretch()
        return tab

    def create_kde_tab(self):
            tab = QWidget()
            layout = QVBoxLayout()
            tab.setLayout(layout)

            help_label = QLabel(
                "KDE (Kernel Density Estimation): genera una superficie continua de densidad de eventos "
                "usando el Kernel Quartic. Útil para identificar focos de concentración (hotspots) "
                "sin la rigidez de los polígonos administrativos." 
            )
            help_label.setWordWrap(True)
            layout.addWidget(help_label)

            form = QFormLayout()

            self.kde_radius_spin = QDoubleSpinBox()
            self.kde_radius_spin.setRange(1, 1000000)
            self.kde_radius_spin.setValue(500.0)
            self.kde_radius_spin.setSuffix(" m")
            self.kde_radius_spin.setToolTip("Radio de búsqueda (banda de ancho) para la estimación de densidad.")

            self.kde_cell_size_spin = QDoubleSpinBox()
            self.kde_cell_size_spin.setRange(1, 1000)
            self.kde_cell_size_spin.setValue(20.0)
            self.kde_cell_size_spin.setSuffix(" m")
            self.kde_cell_size_spin.setToolTip("Tamaño de píxel del raster resultante (menor es más detallado pero más lento).")

            form.addRow("Radio de búsqueda:", self.kde_radius_spin)
            form.addRow("Tamaño de celda:", self.kde_cell_size_spin)
            layout.addLayout(form)

            run_button = QPushButton("Ejecutar KDE")
            run_button.clicked.connect(self.run_kde)
            layout.addWidget(run_button)

            layout.addStretch()
            return tab

    def create_help_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setHtml("""
        <h2>Metodología</h2>
        <p><b>CAT</b> reúne técnicas de geoperfilación criminal y análisis espacial del delito. Nivel Avanzado.</p>

        <h3>Círculos de Canter</h3>
        <p>Genera un círculo de análisis a partir de una serie de eventos puntuales y un centro medio.</p>

        <h3>Rectángulos de Gottlieb</h3>
        <p>Genera un rectángulo/cuadrado envolvente del patrón espacial observado.</p>

        <h3>Journey to Crime</h3>
        <p>Calcula distancias y líneas entre un punto ancla y múltiples eventos.</p>

        <h3>Fórmula de Rossmo</h3>
        <p>Produce una superficie raster de priorización espacial basada en una implementación operativa de la fórmula de Rossmo.</p>

        <h3>Near Repeat Calculator</h3>
        <p>Identifica pares de eventos cercanos en espacio y tiempo según umbrales definidos por el usuario.</p>

        <h3>Getis-Ord Gi*</h3>
        <p>Detecta hotspots y coldspots locales sobre una capa poligonal a partir de un campo numérico.</p>

        <h3>Risk Terrain Modelling</h3>
        <p>Combina hasta tres factores geográficos en una superficie de riesgo relativo mediante suma ponderada.</p>

        <h3>KDE</h3>
        <p>Estimación de densidad mediante función Kernel Quartic para identificar centros de gravedad de eventos.</p>

        <h3>Recomendaciones generales</h3>
        <ul>
            <li>Usar siempre capas en un CRS proyectado en metros.</li>
            <li>Revisar la calidad de los datos antes de interpretar resultados.</li>
            <li>Interpretar los resultados con criterio técnico y contexto territorial.</li>
        </ul>
        """)
        layout.addWidget(browser)
        return tab

    def create_about_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setHtml("""
        <h2>CAT</h2>
        <p><b>Versión:</b> 0.2.5</p>
        <p>Plugin experimental NO OFICIAL para QGIS para la geoperfilación criminal y el análisis espacial del delito. Nivel Avanzado.</p>

        <h3>Módulos incluidos</h3>
        <ul>
            <li>Círculos de Canter</li>
            <li>Rectángulos de Gottlieb</li>
            <li>Journey to Crime</li>
            <li>Fórmula de Rossmo</li>
            <li>Near Repeat Calculator</li>
            <li>Getis-Ord Gi*</li>
            <li>Rusk Terrain Modelling</li>
            <li>KDE</li>
        </ul>

        <h3>Estado</h3>
        <p>Versión mejorada con hiatus indefinido.</p>

        <h3>Nota de responsabilidad</h3>
        <p>Este plugin es una herramienta de apoyo analítico. Sus resultados deben interpretarse con criterio técnico, revisión metodológica y contexto territorial.</p>

        <h3>Licencia</h3>
        <p>GPL v3</p>

        <h3>Autoría</h3>
        <p>EAI. Escobar Estrada Omar & El Gran Maestre de la Cartografía: el Gran Gato Cósmico! Zacatecas, MX - 2026</p>
        """)
        layout.addWidget(browser)
        return tab

    # =========================================================
    # RTM - gestión de factores
    # =========================================================
    def add_rtm_factor(self):
        if len(self.rtm_factors) >= 3:
            msg = "RTM v0.1 admite un máximo de 3 factores."
            self.append_result("RTM", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        layer = self.rtm_layer_combo.currentLayer()

        if not layer:
            msg = "Debes seleccionar una capa válida para el factor."
            self.append_result("RTM", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        factor_name = self.rtm_factor_name_edit.text().strip() or layer.name()
        influence_type = self.rtm_influence_combo.currentText().strip().lower()
        distance = self.rtm_distance_spin.value()
        weight = self.rtm_weight_spin.value()

        factor = {
            "layer": layer,
            "layer_id": layer.id(),
            "factor_name": factor_name,
            "influence_type": influence_type,
            "distance": distance,
            "weight": weight
        }

        self.rtm_factors.append(factor)
        self.refresh_rtm_table()

        self.rtm_factor_name_edit.clear()
        self.append_info("RTM", f"Factor agregado: {factor_name}")
        self.set_status("Factor RTM agregado.")

    def refresh_rtm_table(self):
        self.rtm_table.setRowCount(0)

        for factor in self.rtm_factors:
            row = self.rtm_table.rowCount()
            self.rtm_table.insertRow(row)

            self.rtm_table.setItem(row, 0, QTableWidgetItem(str(factor["factor_name"])))
            self.rtm_table.setItem(row, 1, QTableWidgetItem(str(factor["layer"].name())))
            self.rtm_table.setItem(row, 2, QTableWidgetItem(str(factor["influence_type"])))
            self.rtm_table.setItem(row, 3, QTableWidgetItem(str(factor["distance"])))
            self.rtm_table.setItem(row, 4, QTableWidgetItem(str(factor["weight"])))

    def remove_selected_rtm_factor(self):
        row = self.rtm_table.currentRow()
        if row < 0 or row >= len(self.rtm_factors):
            msg = "Debes seleccionar un factor en la tabla."
            self.append_result("RTM", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        factor_name = self.rtm_factors[row]["factor_name"]
        del self.rtm_factors[row]
        self.refresh_rtm_table()
        self.append_info("RTM", f"Factor eliminado: {factor_name}")
        self.set_status("Factor RTM eliminado.")

    def clear_rtm_factors(self):
        self.rtm_factors = []
        self.refresh_rtm_table()
        self.append_info("RTM", "Lista de factores RTM limpiada.")
        self.set_status("Factores RTM limpiados.")

    # =========================================================
    # Resultados / log
    # =========================================================
    def append_result(self, title, message, is_error=False):
        timestamp = QDateTime.currentDateTime().toString("HH:mm:ss") # Hora más limpia

        if is_error:
            label = "ERROR"
            border_color = "#e53935" # Rojo
            title_color = "#e53935"
        else:
            label = "OK"
            border_color = "#43a047" # Verde
            title_color = "#43a047"

        safe_message = (
            str(message)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\n", "<br>")
        )

        html = f"""
        <div style="
            border-left: 4px solid {border_color};
            padding: 4px 10px;
            margin: 4px 0;
        ">
            <div style="font-weight: bold; color: {title_color}; margin-bottom: 2px;">
                [{label}] {timestamp} | {title}
            </div>
            <div style="margin-left: 4px;">{safe_message}</div>
        </div>
        """

        self.results_text.moveCursor(QTextCursor.End)
        self.results_text.insertHtml(html)
        self.results_text.insertHtml("<br>")
        self.results_text.moveCursor(QTextCursor.End)

    def append_info(self, title, message):
        timestamp = QDateTime.currentDateTime().toString("HH:mm:ss")

        safe_message = (
            str(message)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\n", "<br>")
        )

        html = f"""
        <div style="
            border-left: 4px solid #1e88e5; /* Azul */
            padding: 4px 10px;
            margin: 4px 0;
        ">
            <div style="font-weight: bold; color: #1e88e5; margin-bottom: 2px;">
                [INFO] {timestamp} | {title}
            </div>
            <div style="margin-left: 4px;">{safe_message}</div>
        </div>
        """

        self.results_text.moveCursor(QTextCursor.End)
        self.results_text.insertHtml(html)
        self.results_text.insertHtml("<br>")
        self.results_text.moveCursor(QTextCursor.End)

    def clear_results(self):
        self.results_text.clear()
        self.set_status("Panel de resultados limpio.")

    def copy_results(self):
        self.results_text.selectAll()
        self.results_text.copy()
        self.results_text.moveCursor(QTextCursor.End)
        QMessageBox.information(self, "GeoProfileQGIS", "Los resultados se copiaron al portapapeles.")
        self.set_status("Resultados copiados.")

    def save_results(self):
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Guardar log",
            "geoprofileqgis_log.txt",
            "Archivos de texto (*.txt)"
        )

        if not file_path:
            return

        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(self.results_text.toPlainText())
            self.append_info("Log", f"Log guardado en: {file_path}")
            self.set_status("Log guardado correctamente.")
        except Exception as e:
            msg = f"No se pudo guardar el log: {e}"
            self.append_result("Log", msg, is_error=True)
            self.set_status("Error al guardar log.", is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)

    def save_results_html(self):
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Guardar resultados HTML",
            "geoprofileqgis_resultados.html",
            "Archivos HTML (*.html)"
        )

        if not file_path:
            return

        try:
            html_content = self.results_text.toHtml()
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(html_content)
            self.append_info("HTML", f"Resultados HTML guardados en: {file_path}")
            self.set_status("HTML guardado correctamente.")
        except Exception as e:
            msg = f"No se pudo guardar el HTML: {e}"
            self.append_result("HTML", msg, is_error=True)
            self.set_status("Error al guardar HTML.", is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)

    def set_status(self, message, is_error=False):
            self.status_label.setText(message)
            if is_error:
                self.status_label.setStyleSheet("""
                    QLabel {
                        color: #ff5252;
                        padding: 4px;
                        font-weight: bold;
                    }
                """)
            else:
                self.status_label.setStyleSheet("""
                    QLabel {
                        padding: 4px;
                        font-weight: bold;
                    }
                """)

    # =========================================================
    # Ejecución de módulos
    # =========================================================
    def run_canter(self):
        layer = self.layer_combo.currentLayer()
        if not layer:
            msg = "No hay una capa de incidentes seleccionada."
            self.append_result("Canter", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        f_name = self.group_field_combo.currentField()
        group_field = f_name if f_name else None

        output_name = build_output_name(
            prefix="canter",
            source_layer_name=layer.name(),
            group_field=group_field
        )

        params = {
            "selected_only": self.selected_only_checkbox.isChecked(),
            "group_field": group_field,
            "radius": self.canter_radius_spin.value(),
            "output_name": output_name
        }

        analysis = CanterAnalysis()
        result = analysis.run(layer, params)

        self.append_result("Canter", result["message"], is_error=not result["success"])

        if result["success"]:
            self.set_status("Canter ejecutado correctamente.")
        else:
            self.set_status("Error en Canter.", is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", result["message"])

    def run_gottlieb(self):
        layer = self.layer_combo.currentLayer()
        if not layer:
            msg = "No hay una capa de incidentes seleccionada."
            self.append_result("Gottlieb", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        f_name = self.group_field_combo.currentField()
        group_field = f_name if f_name else None

        output_name = build_output_name(
            prefix="gottlieb",
            source_layer_name=layer.name(),
            group_field=group_field
        )

        params = {
            "selected_only": self.selected_only_checkbox.isChecked(),
            "group_field": group_field,
            "margin": self.gottlieb_margin_spin.value(),
            "output_name": output_name
        }

        analysis = GottliebAnalysis()
        result = analysis.run(layer, params)

        self.append_result("Gottlieb", result["message"], is_error=not result["success"])
 
        if result["success"]:
            self.set_status("Gottlieb ejecutado correctamente.")
        else:
            self.set_status("Error en Gottlieb.", is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", result["message"])

    def run_jtc(self):
        event_layer = self.layer_combo.currentLayer()
        anchor_layer = self.anchor_layer_combo.currentLayer()

        if not event_layer:
            msg = "No hay una capa de eventos seleccionada."
            self.append_result("Journey to Crime", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        if not anchor_layer:
            msg = "No hay una capa de ancla seleccionada."
            self.append_result("Journey to Crime", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        output_name = build_output_name(
            prefix="jtc",
            source_layer_name=event_layer.name(),
            group_field=None
        )

        method_selection = self.jtc_method_combo.currentText()
        distance_method = "manhattan" if "Manhattan" in method_selection else "euclidean"

        params = {
            "selected_only": self.selected_only_checkbox.isChecked(),
            "output_name": output_name,
            "distance_method": distance_method # Pasamos el parámetro al motor
        }

        analysis = JourneyToCrimeAnalysis()
        result = analysis.run(event_layer, anchor_layer, params)

        self.append_result("Journey to Crime", result["message"], is_error=not result["success"])

        if result["success"]:
            self.set_status("Journey to Crime ejecutado correctamente.")
        else:
            self.set_status("Error en Journey to Crime.", is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", result["message"])

    def run_rossmo(self):
        layer = self.layer_combo.currentLayer()
        if not layer:
            msg = "Debes seleccionar una capa de incidentes válida."
            self.append_result("Rossmo", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        params = {
            "selected_only": self.selected_only_checkbox.isChecked(),
            "cell_size": self.rossmo_cell_size_spin.value(),
            "margin": self.rossmo_margin_spin.value(),
            "buffer_zone": self.rossmo_buffer_spin.value(),
            "f": self.rossmo_f_spin.value(),
            "g": self.rossmo_g_spin.value(),
            "k": self.rossmo_k_spin.value(),
            "output_name": build_output_name(
                prefix="rossmo",
                source_layer_name=layer.name()
            )
        }
  
        analysis = RossmoAnalysis()

        progress = QProgressDialog("Preparando Rossmo...", "Cancelar", 0, 100, self)
        progress.setWindowTitle("GeoProfileQGIS")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)

        def progress_callback(value, text=None):
            progress.setValue(value)
            if text:
                progress.setLabelText(text)
            QApplication.processEvents()

        def is_cancelled():
            QApplication.processEvents()
            return progress.wasCanceled()

        try:
            self.set_status("Ejecutando Rossmo...")
            result = analysis.run(
                layer,
                params,
                progress_callback=progress_callback,
                is_cancelled_callback=is_cancelled
            )
            progress.setValue(100)

            if result.get("success"):
                self.append_result("Rossmo", result.get("message", "Análisis ejecutado correctamente."))
                self.set_status("Rossmo finalizado correctamente.")
            else:
                self.append_result("Rossmo", result.get("message", "Error desconocido."), is_error=True)
                self.set_status("Error en Rossmo.", is_error=True)

        except Exception as e:
            self.append_result("Rossmo", f"Error inesperado: {str(e)}", is_error=True)
            self.set_status("Error inesperado en Rossmo.", is_error=True)
            QMessageBox.critical(self, "GeoProfileQGIS", f"Error en Rossmo:\n{str(e)}")
  
        finally:
            progress.close()

    def run_near_repeat(self):
        layer = self.layer_combo.currentLayer()
        if not layer:
            msg = "No hay una capa de incidentes seleccionada."
            self.append_result("Near Repeat", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        f_name = self.near_repeat_time_field_combo.currentField()
        time_field = f_name if f_name else None

        output_name = build_output_name(
            prefix="near_repeat",
            source_layer_name=layer.name(),
            group_field=None
        )

        params = {
            "selected_only": self.selected_only_checkbox.isChecked(),
            "time_field": time_field,
            "spatial_threshold": self.near_repeat_spatial_spin.value(),
            "temporal_threshold": self.near_repeat_temporal_spin.value(),
            "temporal_unit": self.near_repeat_unit_combo.currentText(),
            "output_name": output_name
        }

        analysis = NearRepeatAnalysis()
        result = analysis.run(layer, params)

        self.append_result("Near Repeat", result["message"], is_error=not result["success"])

        if result["success"]:
            self.set_status("Near Repeat ejecutado correctamente.")
        else:
            self.set_status("Error en Near Repeat.", is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", result["message"])

    def run_gi(self):
        layer = self.gi_layer_combo.currentLayer()
        if not layer:
            msg = "No hay una capa poligonal seleccionada."
            self.append_result("Getis-Ord Gi*", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        f_name = self.gi_field_combo.currentField()
        value_field = f_name if f_name else None

        if not value_field:
            msg = "Debes seleccionar un campo numérico válido."
            self.append_result("Getis-Ord Gi*", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        output_name = build_output_name(
            prefix="getis_ord_gi",
            source_layer_name=layer.name()
        )

        params = {
            "value_field": value_field,
            "distance_band": self.gi_distance_spin.value(),
            "include_self": self.gi_include_self_checkbox.isChecked(),
            "selected_only": self.selected_only_checkbox.isChecked(),
            "output_name": output_name
        }

        analysis = GetisOrdGiAnalysis()
        result = analysis.run(layer, params)

        self.append_result("Getis-Ord Gi*", result["message"], is_error=not result["success"])

        if result["success"]:
             self.set_status("Getis-Ord Gi* ejecutado correctamente.")
        else:
            self.set_status("Error en Getis-Ord Gi*.", is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", result["message"])

    def run_rtm(self):
        if not self.rtm_factors:
            msg = "Debes agregar al menos un factor para ejecutar RTM."
            self.append_result("RTM", msg, is_error=True)
            self.set_status(msg, is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", msg)
            return

        output_name = build_output_name(
            prefix="rtm",
            source_layer_name="multi_factor",
            group_field=None
        )

        params = {
            "cell_size": self.rtm_cell_size_spin.value(),
            "margin": self.rtm_margin_spin.value(),
            "output_name": output_name
        }

        progress = QProgressDialog("Ejecutando RTM...", "Cancelar", 0, 100, self)
        progress.setWindowTitle("GeoProfileQGIS")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)

        def progress_callback(value, text=None):
            progress.setValue(int(value))
            if text:
                progress.setLabelText(text)
            QApplication.processEvents()

        def is_cancelled_callback():
            QApplication.processEvents()
            return progress.wasCanceled()

        analysis = RTMAnalysis()
        result = analysis.run(
            self.rtm_factors,
            params,
            progress_callback=progress_callback,
            is_cancelled_callback=is_cancelled_callback
        )

        progress.close()

        self.append_result("RTM", result["message"], is_error=not result["success"])

        if result["success"]:
            self.set_status("RTM ejecutado correctamente.")
        else:
            self.set_status("Error en RTM.", is_error=True)
            QMessageBox.warning(self, "GeoProfileQGIS", result["message"])

    def run_kde(self):
            layer = self.layer_combo.currentLayer()
            if not layer:
                self.append_result("KDE", "No hay capa seleccionada.", is_error=True)
                return

            params = {
                "selected_only": self.selected_only_checkbox.isChecked(),
                "radius": self.kde_radius_spin.value(),
                "cell_size": self.kde_cell_size_spin.value(),
                "output_name": build_output_name("kde", layer.name())
            }

            analysis = KDEAnalysis()
            result = analysis.run(layer, params)
            self.append_result("KDE", result["message"], is_error=not result["success"])