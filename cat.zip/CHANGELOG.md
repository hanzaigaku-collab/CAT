##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
##################################################################
########## ░▒▓██████▓▒░ ░▒▓██████▓▒░▒▓████████▓▒░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓████████▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##########░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░          ###########
########## ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▒░   ░▒▓█▓▒░###########
##################################################################
############## CARTOGRAPHIC ASSISTANT TOOL-CAT! ##################
##################################################################
####################################### ZACATECAS, MX - 2026 #####
##################################################################
############## 01001111 01001101 01000001 01010010 ###############
##################################################################
# 01000101 01010011 01000011 01001111 01000010 01000001 01010010 #
##################################################################
# 01000101 01010011 01010100 01010010 01000001 01000100 01000001 #
##################################################################


\# Changelog



\## \[0.2.5] - 2026-05-22

\### Añadido

\- Soporte para cálculo de distancia Manhattan en Journey to Crime (aún no network analysis pero es un avance).

\- Función `add\_features` para inserción masiva en memoria, reduciendo tiempos de espera en 90%.

\- Soporte para agrupación (Group By) en módulos de perfilación (Canter, Gottlieb).

\- Índices espaciales (`QgsSpatialIndex`) en Getis-Ord para escalar a miles de polígonos.

\- Soporte de "Dark Mode" en toda la interfaz mediante widgets nativos de QGIS.

\- Añadido KDE de último minuto (para que no se casen con la interpolación clásica).



\### Optimizado

\- Motor de Rossmo vectorizado con NumPy: cálculos de superficie de riesgo ahora en ms.

\- Normalización de arrays: ahora ignora valores `NoData` para evitar sesgos en el score de riesgo.

\- Limpieza de nombres de capas: uso de Regex para prevenir caracteres prohibidos en sistemas operativos.



\### Corregido

\- Bug de normalización que aplastaba valores de riesgo con valores NoData.

\- Error de manejo de geometrías `MultiPoint` en validadores y centros medios.

\- Fuga de memoria en el panel de resultados al usar `QTextEdit`.

